from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_from_directory
from database import init_db, register_user, authenticate_user, get_all_users, send_message, get_messages, get_user_by_id, search_users_by_phone, get_user_chats, get_current_user_profile, update_user_profile, update_message, delete_message, toggle_pin_message, forward_message, get_message_by_id, hide_message_for_user, toggle_reaction, get_reactions_for_messages, get_user_reactions, mark_messages_read, get_unread_counts, update_last_seen, get_online_status, update_avatar, update_bio, search_messages, get_messages_page, add_contact, remove_contact, get_contacts, is_contact, create_group, get_user_groups, get_group_messages, send_group_message, get_group_info
import os
from werkzeug.utils import secure_filename
from datetime import datetime
import uuid

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Секретный ключ для сессий

# Настройки для загрузки файлов
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB максимум

# Создаем папку для загрузок, если её нет
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    """Проверка расширения файла"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

ALLOWED_VOICE_EXTENSIONS = {'webm', 'ogg', 'oga', 'mp3'}
def allowed_voice_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_VOICE_EXTENSIONS

ALLOWED_AVATAR_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Инициализация базы данных при запуске
init_db()

@app.before_request
def refresh_last_seen():
    if 'user_id' in session:
        update_last_seen(session['user_id'])

@app.route('/')
def index():
    """Главная страница - редирект на авторизацию"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    """Страница авторизации"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/register')
def register():
    """Страница регистрации"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/api/register', methods=['POST'])
def api_register():
    """API endpoint для регистрации"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        password = data.get('password', '').strip()
        
        # Валидация
        if not phone or not password:
            return jsonify({'success': False, 'message': 'Номер телефона и пароль обязательны'}), 400
        
        # Простая валидация номера телефона (только цифры, минимум 10 символов)
        if not phone.isdigit() or len(phone) < 10:
            return jsonify({'success': False, 'message': 'Некорректный номер телефона'}), 400
        
        if len(password) < 6:
            return jsonify({'success': False, 'message': 'Пароль должен содержать минимум 6 символов'}), 400
        
        # Регистрация пользователя
        user_id = register_user(phone, password)
        
        if user_id:
            session['user_id'] = user_id
            session['phone'] = phone
            return jsonify({'success': True, 'message': 'Регистрация успешна', 'redirect': '/dashboard'})
        else:
            return jsonify({'success': False, 'message': 'Пользователь с таким номером уже существует'}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/login', methods=['POST'])
def api_login():
    """API endpoint для авторизации"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        password = data.get('password', '').strip()
        
        # Валидация
        if not phone or not password:
            return jsonify({'success': False, 'message': 'Номер телефона и пароль обязательны'}), 400
        
        # Аутентификация
        user = authenticate_user(phone, password)
        
        if user:
            session['user_id'] = user['id']
            session['phone'] = user['phone']
            return jsonify({'success': True, 'message': 'Вход выполнен успешно', 'redirect': '/dashboard'})
        else:
            return jsonify({'success': False, 'message': 'Неверный номер телефона или пароль'}), 401
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """API endpoint для выхода"""
    session.clear()
    return jsonify({'success': True, 'redirect': '/login'})

@app.route('/dashboard')
def dashboard():
    """Страница после успешной авторизации"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', phone=session.get('phone'), user_id=session.get('user_id'))

@app.route('/api/chats', methods=['GET'])
def api_get_chats():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    try:
        chats = get_user_chats(session['user_id'])
        unread = get_unread_counts(session['user_id'])
        for chat in chats:
            chat['unread'] = unread.get(chat['id'], 0)
        return jsonify({'success': True, 'chats': chats})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/users/search', methods=['GET'])
def api_search_users():
    """API endpoint для поиска пользователей по ID"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401

    try:
        search_query = request.args.get('q', '').strip()

        if not search_query:
            return jsonify({'success': True, 'users': []})

        users = search_users_by_phone(session['user_id'], search_query)
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages', methods=['GET'])
def api_get_messages():
    """API endpoint для получения сообщений с другим пользователем"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        other_user_id = request.args.get('user_id', type=int)
        if not other_user_id:
            return jsonify({'success': False, 'message': 'ID пользователя не указан'}), 400
        
        messages = get_messages(session['user_id'], other_user_id)
        # Отмечаем сообщения собеседника как прочитанные
        mark_messages_read(session['user_id'], other_user_id)
        return jsonify({'success': True, 'messages': messages})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages', methods=['POST'])
def api_send_message():
    """API endpoint для отправки сообщения"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        receiver_id = request.form.get('receiver_id', type=int)
        message = request.form.get('message', '').strip()
        
        if not receiver_id:
            return jsonify({'success': False, 'message': 'ID получателя не указан'}), 400
        
        image_path = None
        voice_path = None
        voice_duration_sec = request.form.get('voice_duration_sec', type=float)
        
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                filename = f"{uuid.uuid4()}_{secure_filename(file.filename)}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                image_path = filename
        
        if 'voice' in request.files:
            file = request.files['voice']
            if file and file.filename and allowed_voice_file(file.filename):
                ext = file.filename.rsplit('.', 1)[1].lower()
                filename = f"voice_{uuid.uuid4()}.{ext}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                voice_path = filename
        
        if not message and not image_path and not voice_path:
            return jsonify({'success': False, 'message': 'Сообщение, изображение или голосовое обязательны'}), 400
        
        reply_to_id = request.form.get('reply_to_id', type=int)
        message_id = send_message(session['user_id'], receiver_id, message if message else None, image_path, reply_to_id, voice_path=voice_path, voice_duration_sec=voice_duration_sec)
        return jsonify({'success': True, 'message_id': message_id, 'image_path': image_path, 'voice_path': voice_path})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """Отдача загруженных файлов (изображения и голосовые)"""
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.isfile(path):
        return '', 404
    mimetype = None
    if filename.startswith('voice_') or filename.lower().endswith(('.webm', '.ogg', '.oga', '.mp3')):
        if filename.lower().endswith('.webm'):
            mimetype = 'audio/webm'
        elif filename.lower().endswith(('.ogg', '.oga')):
            mimetype = 'audio/ogg'
        elif filename.lower().endswith('.mp3'):
            mimetype = 'audio/mpeg'
        else:
            mimetype = 'audio/webm'
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, mimetype=mimetype)

@app.route('/api/messages/<int:message_id>', methods=['PUT'])
def api_update_message(message_id):
    """API endpoint для обновления сообщения"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        data = request.get_json()
        new_message = data.get('message', '').strip()
        
        if not new_message:
            return jsonify({'success': False, 'message': 'Сообщение не может быть пустым'}), 400
        
        if update_message(message_id, session['user_id'], new_message):
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Сообщение не найдено или нет прав на редактирование'}), 403
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages/<int:message_id>', methods=['DELETE'])
def api_delete_message(message_id):
    """API endpoint для удаления сообщения. scope=me — только у себя, scope=everyone — у всех (только отправитель)."""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    scope = request.args.get('scope', 'me').lower()
    try:
        if scope == 'everyone':
            if delete_message(message_id, session['user_id']):
                return jsonify({'success': True})
            return jsonify({'success': False, 'message': 'Сообщение не найдено или нет прав на удаление'}), 403
        else:
            if hide_message_for_user(session['user_id'], message_id):
                return jsonify({'success': True})
            return jsonify({'success': False, 'message': 'Сообщение не найдено'}), 403
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages/<int:message_id>/pin', methods=['POST'])
def api_toggle_pin(message_id):
    """API endpoint для закрепления/открепления сообщения"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        is_pinned = toggle_pin_message(message_id, session['user_id'])
        if is_pinned is not False:
            return jsonify({'success': True, 'is_pinned': is_pinned})
        else:
            return jsonify({'success': False, 'message': 'Сообщение не найдено или нет прав'}), 403
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages/<int:message_id>/forward', methods=['POST'])
def api_forward_message(message_id):
    """API endpoint для пересылки сообщения"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        data = request.get_json()
        receiver_id = data.get('receiver_id')
        
        if not receiver_id:
            return jsonify({'success': False, 'message': 'ID получателя не указан'}), 400
        
        new_message_id = forward_message(message_id, session['user_id'], receiver_id)
        if new_message_id:
            return jsonify({'success': True, 'message_id': new_message_id})
        else:
            return jsonify({'success': False, 'message': 'Сообщение не найдено'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages/<int:message_id>', methods=['GET'])
def api_get_message(message_id):
    """API endpoint для получения сообщения по ID"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        message = get_message_by_id(message_id)
        if message:
            # Проверяем, что пользователь участвует в чате
            if message['sender_id'] != session['user_id'] and message['receiver_id'] != session['user_id']:
                return jsonify({'success': False, 'message': 'Нет доступа'}), 403
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': 'Сообщение не найдено'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/user/<int:user_id>', methods=['GET'])
def api_get_user(user_id):
    """API endpoint для получения информации о пользователе"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        user = get_user_by_id(user_id)
        if user:
            return jsonify({'success': True, 'user': user})
        else:
            return jsonify({'success': False, 'message': 'Пользователь не найден'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/profile', methods=['GET'])
def api_get_profile():
    """API endpoint для получения профиля текущего пользователя"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        profile = get_current_user_profile(session['user_id'])
        if profile:
            return jsonify({'success': True, 'profile': profile})
        else:
            return jsonify({'success': False, 'message': 'Профиль не найден'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/profile', methods=['PUT'])
def api_update_profile():
    """API endpoint для обновления профиля"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        data = request.get_json()
        username = data.get('username', '').strip() if data.get('username') else None
        
        if username and len(username) > 50:
            return jsonify({'success': False, 'message': 'Ник не может быть длиннее 50 символов'}), 400
        
        update_user_profile(session['user_id'], username)
        profile = get_current_user_profile(session['user_id'])
        return jsonify({'success': True, 'profile': profile})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages/search', methods=['GET'])
def api_search_messages():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    other_id = request.args.get('user_id', type=int)
    query = request.args.get('q', '').strip()
    if not other_id or not query:
        return jsonify({'success': True, 'messages': []})
    msgs = search_messages(session['user_id'], other_id, query)
    return jsonify({'success': True, 'messages': msgs})

@app.route('/api/messages/page', methods=['GET'])
def api_messages_page():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    other_id = request.args.get('user_id', type=int)
    before_id = request.args.get('before_id', type=int)
    if not other_id:
        return jsonify({'success': False}), 400
    msgs = get_messages_page(session['user_id'], other_id, before_id)
    ids = [m['id'] for m in msgs]
    reactions = get_reactions_for_messages(ids)
    user_reacts = get_user_reactions(ids, session['user_id'])
    for m in msgs:
        m['reactions'] = reactions.get(m['id'], {})
        m['my_reactions'] = user_reacts.get(m['id'], [])
    return jsonify({'success': True, 'messages': msgs, 'has_more': len(msgs) == 40})

@app.route('/api/messages/<int:message_id>/react', methods=['POST'])
def api_react(message_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    data = request.get_json()
    emoji = data.get('emoji', '').strip()
    if not emoji:
        return jsonify({'success': False, 'message': 'emoji required'}), 400
    result = toggle_reaction(message_id, session['user_id'], emoji)
    return jsonify({'success': True, **result})

@app.route('/api/messages/read', methods=['POST'])
def api_mark_read():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    data = request.get_json()
    sender_id = data.get('sender_id')
    if not sender_id:
        return jsonify({'success': False}), 400
    mark_messages_read(session['user_id'], sender_id)
    return jsonify({'success': True})

@app.route('/api/unread', methods=['GET'])
def api_unread():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    counts = get_unread_counts(session['user_id'])
    return jsonify({'success': True, 'unread': counts})

@app.route('/api/user/<int:user_id>/status', methods=['GET'])
def api_user_status(user_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    status = get_online_status(user_id)
    return jsonify({'success': True, **status})

@app.route('/api/profile/avatar', methods=['POST'])
def api_upload_avatar():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    if 'avatar' not in request.files:
        return jsonify({'success': False, 'message': 'Файл не найден'}), 400
    file = request.files['avatar']
    if not file or not file.filename:
        return jsonify({'success': False, 'message': 'Пустой файл'}), 400
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if ext not in ALLOWED_AVATAR_EXTENSIONS:
        return jsonify({'success': False, 'message': 'Недопустимый формат'}), 400
    filename = f"avatar_{session['user_id']}_{uuid.uuid4()}.{ext}"
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    update_avatar(session['user_id'], filename)
    return jsonify({'success': True, 'avatar_path': filename})

@app.route('/api/profile/bio', methods=['PUT'])
def api_update_bio():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    data = request.get_json()
    bio = (data.get('bio') or '').strip()[:200]
    update_bio(session['user_id'], bio)
    return jsonify({'success': True})

# ─── КОНТАКТЫ ────────────────────────────────────────────────────────────────

@app.route('/api/contacts', methods=['GET'])
def api_get_contacts():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    contacts = get_contacts(session['user_id'])
    return jsonify({'success': True, 'contacts': contacts})

@app.route('/api/contacts', methods=['POST'])
def api_add_contact():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    data = request.get_json()
    contact_id = data.get('contact_id')
    if not contact_id:
        return jsonify({'success': False, 'message': 'contact_id required'}), 400
    added = add_contact(session['user_id'], int(contact_id))
    return jsonify({'success': True, 'added': added})

@app.route('/api/contacts/<int:contact_id>', methods=['DELETE'])
def api_remove_contact(contact_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    remove_contact(session['user_id'], contact_id)
    return jsonify({'success': True})

@app.route('/api/contacts/check', methods=['GET'])
def api_check_contact():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    contact_id = request.args.get('id', type=int)
    if not contact_id:
        return jsonify({'success': False}), 400
    result = is_contact(session['user_id'], contact_id)
    return jsonify({'success': True, 'is_contact': result})

# ─── ГРУППЫ ──────────────────────────────────────────────────────────────────

@app.route('/api/groups', methods=['GET'])
def api_get_groups():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    groups = get_user_groups(session['user_id'])
    return jsonify({'success': True, 'groups': groups})

@app.route('/api/groups', methods=['POST'])
def api_create_group():
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    data = request.get_json()
    name = (data.get('name') or '').strip()
    member_ids = data.get('member_ids', [])
    if not name:
        return jsonify({'success': False, 'message': 'Название группы обязательно'}), 400
    if not member_ids:
        return jsonify({'success': False, 'message': 'Выберите хотя бы одного участника'}), 400
    group_id = create_group(name, session['user_id'], [int(i) for i in member_ids])
    return jsonify({'success': True, 'group_id': group_id})

@app.route('/api/groups/<int:group_id>', methods=['GET'])
def api_get_group(group_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    info = get_group_info(group_id, session['user_id'])
    if not info:
        return jsonify({'success': False, 'message': 'Группа не найдена или нет доступа'}), 404
    return jsonify({'success': True, 'group': info})

@app.route('/api/groups/<int:group_id>/messages', methods=['GET'])
def api_get_group_messages(group_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    msgs = get_group_messages(group_id, session['user_id'])
    if msgs is None:
        return jsonify({'success': False, 'message': 'Нет доступа'}), 403
    return jsonify({'success': True, 'messages': msgs})

@app.route('/api/groups/<int:group_id>/messages', methods=['POST'])
def api_send_group_message(group_id):
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    message = request.form.get('message', '').strip()
    image_path = None
    if 'image' in request.files:
        file = request.files['image']
        if file and file.filename and allowed_file(file.filename):
            filename = f"{uuid.uuid4()}_{secure_filename(file.filename)}"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            image_path = filename
    if not message and not image_path:
        return jsonify({'success': False, 'message': 'Сообщение обязательно'}), 400
    msg_id = send_group_message(group_id, session['user_id'], message or None, image_path)
    if not msg_id:
        return jsonify({'success': False, 'message': 'Нет доступа'}), 403
    return jsonify({'success': True, 'message_id': msg_id})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
