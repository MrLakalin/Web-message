import sqlite3
import bcrypt
import os
import random
import string

DB_NAME = 'messenger.db'

def get_db_connection():
    """Создание подключения к базе данных"""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Инициализация базы данных - создание таблиц пользователей и сообщений"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            user_id TEXT UNIQUE,
            username TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Добавляем новые колонки, если их нет (для существующих баз данных)
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN user_id TEXT UNIQUE')
    except sqlite3.OperationalError:
        pass  # Колонка уже существует
    
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN username TEXT')
    except sqlite3.OperationalError:
        pass  # Колонка уже существует
    
    # Генерируем user_id для пользователей, у которых его нет
    cursor.execute('SELECT id, phone FROM users WHERE user_id IS NULL')
    users_without_id = cursor.fetchall()
    for user in users_without_id:
        # Генерируем уникальный user_id из 8 символов
        while True:
            new_user_id = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            cursor.execute('SELECT id FROM users WHERE user_id = ?', (new_user_id,))
            if not cursor.fetchone():
                cursor.execute('UPDATE users SET user_id = ? WHERE id = ?', (new_user_id, user['id']))
                break
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            message TEXT,
            image_path TEXT,
            reply_to_id INTEGER,
            is_pinned INTEGER DEFAULT 0,
            is_deleted INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id),
            FOREIGN KEY (reply_to_id) REFERENCES messages(id)
        )
    ''')
    
    # Добавляем новые колонки, если их нет
    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN image_path TEXT')
    except sqlite3.OperationalError:
        pass
    
    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN reply_to_id INTEGER')
    except sqlite3.OperationalError:
        pass
    
    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN is_pinned INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass
    
    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN is_deleted INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass
    
    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN updated_at TIMESTAMP')
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN voice_path TEXT')
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute('ALTER TABLE messages ADD COLUMN voice_duration_sec REAL')
    except sqlite3.OperationalError:
        pass

    # Проверяем структуру таблицы messages и исправляем, если нужно
    cursor.execute("PRAGMA table_info(messages)")
    columns = cursor.fetchall()
    message_col = None
    for col in columns:
        if col[1] == 'message':
            message_col = col
            break
    
    # Если поле message имеет ограничение NOT NULL, пересоздаем таблицу
    if message_col and message_col[3] == 1:  # 1 означает NOT NULL
        try:
            # Создаем новую таблицу с правильной структурой
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender_id INTEGER NOT NULL,
                    receiver_id INTEGER NOT NULL,
                    message TEXT,
                    image_path TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (sender_id) REFERENCES users(id),
                    FOREIGN KEY (receiver_id) REFERENCES users(id)
                )
            ''')
            
            # Копируем данные из старой таблицы
            cursor.execute('''
                INSERT INTO messages_new (id, sender_id, receiver_id, message, image_path, created_at)
                SELECT id, sender_id, receiver_id, message, COALESCE(image_path, NULL), created_at
                FROM messages
            ''')
            
            # Удаляем старую таблицу и переименовываем новую
            cursor.execute('DROP TABLE messages')
            cursor.execute('ALTER TABLE messages_new RENAME TO messages')
            conn.commit()
        except sqlite3.OperationalError as e:
            # Если что-то пошло не так, откатываем изменения
            conn.rollback()
            print(f"Предупреждение: не удалось обновить структуру таблицы messages: {e}")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_hidden_messages (
            user_id INTEGER NOT NULL,
            message_id INTEGER NOT NULL,
            PRIMARY KEY (user_id, message_id),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (message_id) REFERENCES messages(id)
        )
    ''')

    # Реакции на сообщения
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS message_reactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            emoji TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(message_id, user_id, emoji),
            FOREIGN KEY (message_id) REFERENCES messages(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # Статус прочитано
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS message_reads (
            message_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            read_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # Онлайн статус и биография
    for col_def in [
        ('ALTER TABLE users ADD COLUMN last_seen TIMESTAMP', None),
        ('ALTER TABLE users ADD COLUMN bio TEXT', None),
        ('ALTER TABLE users ADD COLUMN avatar_path TEXT', None),
    ]:
        try:
            cursor.execute(col_def[0])
        except sqlite3.OperationalError:
            pass

    # Контакты
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contacts (
            owner_id INTEGER NOT NULL,
            contact_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (owner_id, contact_id),
            FOREIGN KEY (owner_id) REFERENCES users(id),
            FOREIGN KEY (contact_id) REFERENCES users(id)
        )
    ''')

    # Группы
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_by INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS group_members (
            group_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (group_id, user_id),
            FOREIGN KEY (group_id) REFERENCES groups(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS group_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            sender_id INTEGER NOT NULL,
            message TEXT,
            image_path TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (group_id) REFERENCES groups(id),
            FOREIGN KEY (sender_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()
    print(f"База данных {DB_NAME} инициализирована")

def hash_password(password):
    """Хеширование пароля с использованием bcrypt"""
    salt = bcrypt.gensalt()
    password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
    return password_hash.decode('utf-8')

def verify_password(password, password_hash):
    """Проверка пароля"""
    return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))

def register_user(phone, password):
    """Регистрация нового пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Проверка существования пользователя
        cursor.execute('SELECT id FROM users WHERE phone = ?', (phone,))
        if cursor.fetchone():
            conn.close()
            return None
        
        # Хеширование пароля
        password_hash = hash_password(password)
        
        # Генерируем уникальный user_id из 8 символов
        while True:
            new_user_id = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            cursor.execute('SELECT id FROM users WHERE user_id = ?', (new_user_id,))
            if not cursor.fetchone():
                break
        
        # Вставка нового пользователя
        cursor.execute(
            'INSERT INTO users (phone, password_hash, user_id) VALUES (?, ?, ?)',
            (phone, password_hash, new_user_id)
        )
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return user_id
        
    except sqlite3.IntegrityError:
        conn.close()
        return None
    except Exception as e:
        conn.close()
        raise e

def authenticate_user(phone, password):
    """Аутентификация пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, phone, password_hash FROM users WHERE phone = ?', (phone,))
    user = cursor.fetchone()
    conn.close()
    
    if user and verify_password(password, user['password_hash']):
        return {
            'id': user['id'],
            'phone': user['phone']
        }
    
    return None

def get_all_users(exclude_user_id):
    """Получение списка всех пользователей кроме текущего"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, phone, username FROM users WHERE id != ? ORDER BY phone LIMIT 50', (exclude_user_id,))
    users = cursor.fetchall()
    conn.close()
    
    return [{'id': user['id'], 'phone': user['phone'], 'username': user['username'] if user['username'] else None} for user in users]

def search_users_by_phone(exclude_user_id, search_query):
    """Поиск пользователей по user_id (с @ или без)"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Убираем @ если есть
    query = search_query.lstrip('@').strip()

    cursor.execute(
        'SELECT id, phone, username, user_id FROM users WHERE id != ? AND user_id LIKE ? ORDER BY user_id LIMIT 20',
        (exclude_user_id, f'%{query}%')
    )
    users = cursor.fetchall()
    conn.close()

    return [{'id': user['id'], 'phone': user['phone'], 'username': user['username'] if user['username'] else None, 'user_id': user['user_id']} for user in users]

def send_message(sender_id, receiver_id, message=None, image_path=None, reply_to_id=None, voice_path=None, voice_duration_sec=None):
    """Отправка сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        '''INSERT INTO messages (sender_id, receiver_id, message, image_path, reply_to_id, voice_path, voice_duration_sec)
           VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (sender_id, receiver_id, message, image_path, reply_to_id, voice_path, voice_duration_sec)
    )
    message_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return message_id

def hide_message_for_user(user_id, message_id):
    """Скрыть сообщение только для одного пользователя («удалить у себя»)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT sender_id, receiver_id FROM messages WHERE id = ?',
        (message_id,)
    )
    msg = cursor.fetchone()
    if not msg or (msg['sender_id'] != user_id and msg['receiver_id'] != user_id):
        conn.close()
        return False
    cursor.execute(
        'INSERT OR IGNORE INTO user_hidden_messages (user_id, message_id) VALUES (?, ?)',
        (user_id, message_id)
    )
    conn.commit()
    conn.close()
    return True


def get_messages(user_id, other_user_id):
    """Получение сообщений между двумя пользователями (с учётом скрытых «у себя»)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT m.id, m.sender_id, m.receiver_id, m.message, m.image_path, m.reply_to_id, m.is_pinned, m.created_at, m.updated_at,
               m.voice_path, m.voice_duration_sec
        FROM messages m
        LEFT JOIN user_hidden_messages h ON h.message_id = m.id AND h.user_id = ?
        WHERE ((m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?))
        AND m.is_deleted = 0
        AND h.message_id IS NULL
        ORDER BY m.is_pinned DESC, m.created_at ASC
    ''', (user_id, user_id, other_user_id, other_user_id, user_id))

    messages = cursor.fetchall()
    msg_ids = [m['id'] for m in messages]

    # Реакции
    reactions_map = {}
    user_reacts_map = {}
    if msg_ids:
        placeholders = ','.join('?' * len(msg_ids))
        cursor.execute(
            f'SELECT message_id, emoji, COUNT(*) as cnt FROM message_reactions WHERE message_id IN ({placeholders}) GROUP BY message_id, emoji',
            msg_ids
        )
        for row in cursor.fetchall():
            reactions_map.setdefault(row['message_id'], {})[row['emoji']] = row['cnt']
        cursor.execute(
            f'SELECT message_id, emoji FROM message_reactions WHERE message_id IN ({placeholders}) AND user_id=?',
            msg_ids + [user_id]
        )
        for row in cursor.fetchall():
            user_reacts_map.setdefault(row['message_id'], []).append(row['emoji'])

    # Статус прочитано
    read_ids = set()
    if msg_ids:
        placeholders = ','.join('?' * len(msg_ids))
        cursor.execute(
            f'SELECT message_id FROM message_reads WHERE message_id IN ({placeholders})',
            msg_ids
        )
        read_ids = {r['message_id'] for r in cursor.fetchall()}

    conn.close()

    return [{
        'id': msg['id'],
        'sender_id': msg['sender_id'],
        'receiver_id': msg['receiver_id'],
        'message': msg['message'],
        'image_path': msg['image_path'],
        'reply_to_id': msg['reply_to_id'],
        'is_pinned': msg['is_pinned'],
        'created_at': msg['created_at'],
        'updated_at': msg['updated_at'],
        'voice_path': msg['voice_path'],
        'voice_duration_sec': msg['voice_duration_sec'],
        'reactions': reactions_map.get(msg['id'], {}),
        'my_reactions': user_reacts_map.get(msg['id'], []),
        'is_read': msg['id'] in read_ids,
    } for msg in messages]

def update_message(message_id, user_id, new_message):
    """Обновление сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Проверяем, что сообщение принадлежит пользователю
    cursor.execute('SELECT sender_id FROM messages WHERE id = ?', (message_id,))
    msg = cursor.fetchone()
    
    if not msg or msg['sender_id'] != user_id:
        conn.close()
        return False
    
    cursor.execute(
        'UPDATE messages SET message = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        (new_message, message_id)
    )
    
    conn.commit()
    conn.close()
    return True

def delete_message(message_id, user_id):
    """Удаление сообщения (мягкое удаление)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Проверяем, что сообщение принадлежит пользователю
    cursor.execute('SELECT sender_id FROM messages WHERE id = ?', (message_id,))
    msg = cursor.fetchone()
    
    if not msg or msg['sender_id'] != user_id:
        conn.close()
        return False
    
    cursor.execute(
        'UPDATE messages SET is_deleted = 1 WHERE id = ?',
        (message_id,)
    )
    
    conn.commit()
    conn.close()
    return True

def toggle_pin_message(message_id, user_id):
    """Закрепление/открепление сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Проверяем, что пользователь участвует в чате
    cursor.execute('SELECT sender_id, receiver_id FROM messages WHERE id = ?', (message_id,))
    msg = cursor.fetchone()
    
    if not msg or (msg['sender_id'] != user_id and msg['receiver_id'] != user_id):
        conn.close()
        return False
    
    # Получаем текущее состояние
    cursor.execute('SELECT is_pinned FROM messages WHERE id = ?', (message_id,))
    current = cursor.fetchone()
    new_pin_state = 1 if not current or current['is_pinned'] == 0 else 0
    
    cursor.execute(
        'UPDATE messages SET is_pinned = ? WHERE id = ?',
        (new_pin_state, message_id)
    )
    
    conn.commit()
    conn.close()
    return new_pin_state == 1

def forward_message(message_id, sender_id, receiver_id):
    """Пересылка сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT message, image_path, voice_path, voice_duration_sec FROM messages WHERE id = ?', (message_id,))
    original = cursor.fetchone()
    if not original:
        conn.close()
        return None
    vp = original['voice_path'] if 'voice_path' in original.keys() else None
    vd = original['voice_duration_sec'] if 'voice_duration_sec' in original.keys() else None
    new_message_id = send_message(sender_id, receiver_id, original['message'], original['image_path'], reply_to_id=None, voice_path=vp, voice_duration_sec=vd)
    conn.close()
    return new_message_id

def get_message_by_id(message_id):
    """Получение сообщения по ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, sender_id, receiver_id, message, image_path, reply_to_id, is_pinned, created_at, updated_at, voice_path, voice_duration_sec
        FROM messages WHERE id = ? AND is_deleted = 0
    ''', (message_id,))
    msg = cursor.fetchone()
    conn.close()
    if not msg:
        return None
    return {
        'id': msg['id'],
        'sender_id': msg['sender_id'],
        'receiver_id': msg['receiver_id'],
        'message': msg['message'],
        'image_path': msg['image_path'],
        'reply_to_id': msg['reply_to_id'],
        'is_pinned': msg['is_pinned'],
        'created_at': msg['created_at'],
        'updated_at': msg['updated_at'],
        'voice_path': msg['voice_path'],
        'voice_duration_sec': msg['voice_duration_sec']
    }

def get_user_by_id(user_id):
    """Получение пользователя по ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, phone, user_id, username, bio, avatar_path, last_seen FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        status = get_online_status(user_id)
        return {
            'id': user['id'],
            'phone': user['phone'],
            'user_id': user['user_id'],
            'username': user['username'],
            'bio': user['bio'],
            'avatar_path': user['avatar_path'],
            'online': status['online'],
            'last_seen': status['last_seen'],
        }
    return None

def get_current_user_profile(user_id):
    """Получение профиля текущего пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, phone, user_id, username, bio, avatar_path FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return {
            'id': user['id'],
            'phone': user['phone'],
            'user_id': user['user_id'],
            'username': user['username'] if user['username'] else None,
            'bio': user['bio'],
            'avatar_path': user['avatar_path'],
        }
    return None

def update_user_profile(user_id, username=None):
    """Обновление профиля пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if username is not None:
            cursor.execute('UPDATE users SET username = ? WHERE id = ?', (username.strip() if username else None, user_id))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        conn.close()
        raise e

def get_user_chats(user_id):
    """Получение списка пользователей, с которыми есть переписка, отсортированных по времени последнего сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Оптимизированный запрос: получаем всех пользователей с перепиской и их последние сообщения за один запрос
    cursor.execute('''
        SELECT 
            u.id,
            u.phone,
            u.username,
            m.message as last_message,
            m.image_path as last_image_path,
            m.voice_path as last_voice_path,
            m.created_at as last_message_time,
            m.sender_id as last_message_sender_id
        FROM users u
        INNER JOIN (
            SELECT 
                CASE 
                    WHEN sender_id = ? THEN receiver_id
                    ELSE sender_id
                END as other_user_id,
                MAX(created_at) as max_time
            FROM messages
            WHERE sender_id = ? OR receiver_id = ?
            GROUP BY other_user_id
        ) latest ON u.id = latest.other_user_id
        INNER JOIN messages m ON (
            (m.sender_id = ? AND m.receiver_id = u.id) OR 
            (m.sender_id = u.id AND m.receiver_id = ?)
        ) AND m.created_at = latest.max_time
        WHERE u.id != ?
        ORDER BY m.created_at DESC
    ''', (user_id, user_id, user_id, user_id, user_id, user_id))
    
    chats = cursor.fetchall()
    
    result = []
    for chat in chats:
        last_msg_text = chat['last_message'] if chat['last_message'] else None
        if not last_msg_text and chat.get('last_image_path'):
            last_msg_text = '📷 Фото'
        if not last_msg_text and chat.get('last_voice_path'):
            last_msg_text = '🎤 Голосовое'
        
        result.append({
            'id': chat['id'],
            'phone': chat['phone'],
            'username': chat['username'] if chat['username'] else None,
            'last_message': last_msg_text,
            'last_message_time': chat['last_message_time'] if chat['last_message_time'] else None,
            'last_message_sender_id': chat['last_message_sender_id'] if chat['last_message_sender_id'] else None
        })
    
    conn.close()
    return result

# ─── РЕАКЦИИ ────────────────────────────────────────────────────────────────

def toggle_reaction(message_id, user_id, emoji):
    """Добавить или убрать реакцию. Возвращает {'added': bool, 'reactions': {...}}"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT id FROM message_reactions WHERE message_id=? AND user_id=? AND emoji=?',
        (message_id, user_id, emoji)
    )
    existing = cursor.fetchone()
    if existing:
        cursor.execute(
            'DELETE FROM message_reactions WHERE message_id=? AND user_id=? AND emoji=?',
            (message_id, user_id, emoji)
        )
        added = False
    else:
        cursor.execute(
            'INSERT INTO message_reactions (message_id, user_id, emoji) VALUES (?,?,?)',
            (message_id, user_id, emoji)
        )
        added = True
    conn.commit()
    reactions = _get_reactions(cursor, message_id)
    conn.close()
    return {'added': added, 'reactions': reactions}

def get_reactions_for_messages(message_ids):
    """Получить реакции для списка сообщений. Возвращает {message_id: {emoji: count}}"""
    if not message_ids:
        return {}
    conn = get_db_connection()
    cursor = conn.cursor()
    placeholders = ','.join('?' * len(message_ids))
    cursor.execute(
        f'SELECT message_id, emoji, COUNT(*) as cnt FROM message_reactions WHERE message_id IN ({placeholders}) GROUP BY message_id, emoji',
        message_ids
    )
    rows = cursor.fetchall()
    # also get which emojis current user reacted — we'll handle per-user in API
    conn.close()
    result = {}
    for row in rows:
        mid = row['message_id']
        if mid not in result:
            result[mid] = {}
        result[mid][row['emoji']] = row['cnt']
    return result

def get_user_reactions(message_ids, user_id):
    """Получить список emoji которые поставил user_id для каждого сообщения"""
    if not message_ids:
        return {}
    conn = get_db_connection()
    cursor = conn.cursor()
    placeholders = ','.join('?' * len(message_ids))
    cursor.execute(
        f'SELECT message_id, emoji FROM message_reactions WHERE message_id IN ({placeholders}) AND user_id=?',
        message_ids + [user_id]
    )
    rows = cursor.fetchall()
    conn.close()
    result = {}
    for row in rows:
        mid = row['message_id']
        if mid not in result:
            result[mid] = []
        result[mid].append(row['emoji'])
    return result

def _get_reactions(cursor, message_id):
    cursor.execute(
        'SELECT emoji, COUNT(*) as cnt FROM message_reactions WHERE message_id=? GROUP BY emoji',
        (message_id,)
    )
    return {row['emoji']: row['cnt'] for row in cursor.fetchall()}


# ─── СТАТУС ПРОЧИТАНО ────────────────────────────────────────────────────────

def mark_messages_read(reader_id, sender_id):
    """Отметить все сообщения от sender_id к reader_id как прочитанные"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        '''SELECT id FROM messages
           WHERE sender_id=? AND receiver_id=? AND is_deleted=0''',
        (sender_id, reader_id)
    )
    msg_ids = [r['id'] for r in cursor.fetchall()]
    for mid in msg_ids:
        cursor.execute(
            'INSERT OR IGNORE INTO message_reads (message_id, user_id) VALUES (?,?)',
            (mid, reader_id)
        )
    conn.commit()
    conn.close()

def get_unread_counts(user_id):
    """Количество непрочитанных сообщений от каждого собеседника"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT m.sender_id, COUNT(*) as cnt
        FROM messages m
        LEFT JOIN message_reads r ON r.message_id = m.id AND r.user_id = ?
        WHERE m.receiver_id = ? AND m.is_deleted = 0 AND r.message_id IS NULL
        GROUP BY m.sender_id
    ''', (user_id, user_id))
    rows = cursor.fetchall()
    conn.close()
    return {row['sender_id']: row['cnt'] for row in rows}


# ─── ОНЛАЙН СТАТУС ──────────────────────────────────────────────────────────

def update_last_seen(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()

def get_online_status(user_id):
    """Возвращает {'online': bool, 'last_seen': str}"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT last_seen FROM users WHERE id = ?', (user_id,))
    row = cursor.fetchone()
    conn.close()
    if not row or not row['last_seen']:
        return {'online': False, 'last_seen': None}
    from datetime import datetime, timezone
    try:
        last = datetime.fromisoformat(str(row['last_seen']))
        now = datetime.utcnow()
        diff = (now - last).total_seconds()
        return {'online': diff < 60, 'last_seen': str(row['last_seen'])}
    except Exception:
        return {'online': False, 'last_seen': str(row['last_seen'])}


# ─── АВАТАР ─────────────────────────────────────────────────────────────────

def update_avatar(user_id, avatar_path):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET avatar_path = ? WHERE id = ?', (avatar_path, user_id))
    conn.commit()
    conn.close()


# ─── БИО ────────────────────────────────────────────────────────────────────

def update_bio(user_id, bio):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET bio = ? WHERE id = ?', (bio, user_id))
    conn.commit()
    conn.close()


# ─── ПОИСК ПО СООБЩЕНИЯМ ────────────────────────────────────────────────────

def search_messages(user_id, other_user_id, query):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT m.id, m.sender_id, m.receiver_id, m.message, m.image_path,
               m.reply_to_id, m.is_pinned, m.created_at, m.updated_at,
               m.voice_path, m.voice_duration_sec
        FROM messages m
        LEFT JOIN user_hidden_messages h ON h.message_id = m.id AND h.user_id = ?
        WHERE ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
          AND m.is_deleted=0 AND h.message_id IS NULL
          AND m.message LIKE ?
        ORDER BY m.created_at DESC
        LIMIT 50
    ''', (user_id, user_id, other_user_id, other_user_id, user_id, f'%{query}%'))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── ПАГИНАЦИЯ СООБЩЕНИЙ ────────────────────────────────────────────────────

def get_messages_page(user_id, other_user_id, before_id=None, limit=40):
    """Загрузка сообщений постранично. before_id — ID сообщения, до которого грузить."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if before_id:
        cursor.execute('''
            SELECT m.id, m.sender_id, m.receiver_id, m.message, m.image_path,
                   m.reply_to_id, m.is_pinned, m.created_at, m.updated_at,
                   m.voice_path, m.voice_duration_sec
            FROM messages m
            LEFT JOIN user_hidden_messages h ON h.message_id=m.id AND h.user_id=?
            WHERE ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
              AND m.is_deleted=0 AND h.message_id IS NULL AND m.id < ?
            ORDER BY m.created_at DESC
            LIMIT ?
        ''', (user_id, user_id, other_user_id, other_user_id, user_id, before_id, limit))
    else:
        cursor.execute('''
            SELECT m.id, m.sender_id, m.receiver_id, m.message, m.image_path,
                   m.reply_to_id, m.is_pinned, m.created_at, m.updated_at,
                   m.voice_path, m.voice_duration_sec
            FROM messages m
            LEFT JOIN user_hidden_messages h ON h.message_id=m.id AND h.user_id=?
            WHERE ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
              AND m.is_deleted=0 AND h.message_id IS NULL
            ORDER BY m.created_at DESC
            LIMIT ?
        ''', (user_id, user_id, other_user_id, other_user_id, user_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return list(reversed([dict(r) for r in rows]))


# ─── КОНТАКТЫ ────────────────────────────────────────────────────────────────

def add_contact(owner_id, contact_id):
    """Добавить пользователя в контакты. Возвращает True если добавлен, False если уже есть."""
    if owner_id == contact_id:
        return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            'INSERT OR IGNORE INTO contacts (owner_id, contact_id) VALUES (?, ?)',
            (owner_id, contact_id)
        )
        added = cursor.rowcount > 0
        conn.commit()
        return added
    finally:
        conn.close()

def remove_contact(owner_id, contact_id):
    """Удалить пользователя из контактов."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'DELETE FROM contacts WHERE owner_id=? AND contact_id=?',
        (owner_id, contact_id)
    )
    removed = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return removed

def get_contacts(owner_id):
    """Получить список контактов пользователя."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT u.id, u.phone, u.username, u.user_id, u.avatar_path, u.last_seen
        FROM contacts c
        JOIN users u ON u.id = c.contact_id
        WHERE c.owner_id = ?
        ORDER BY u.username, u.phone
    ''', (owner_id,))
    rows = cursor.fetchall()
    conn.close()
    result = []
    for u in rows:
        status = get_online_status(u['id'])
        result.append({
            'id': u['id'],
            'phone': u['phone'],
            'username': u['username'],
            'user_id': u['user_id'],
            'avatar_path': u['avatar_path'],
            'online': status['online'],
        })
    return result

def is_contact(owner_id, contact_id):
    """Проверить, есть ли пользователь в контактах."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        'SELECT 1 FROM contacts WHERE owner_id=? AND contact_id=?',
        (owner_id, contact_id)
    )
    result = cursor.fetchone() is not None
    conn.close()
    return result


# ─── ГРУППЫ ──────────────────────────────────────────────────────────────────

def create_group(name, creator_id, member_ids):
    """Создать группу. member_ids — список ID участников (без создателя)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO groups (name, created_by) VALUES (?, ?)', (name, creator_id))
    group_id = cursor.lastrowid
    # Добавляем создателя и участников
    all_members = list(set([creator_id] + member_ids))
    for uid in all_members:
        cursor.execute('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?, ?)', (group_id, uid))
    conn.commit()
    conn.close()
    return group_id

def get_user_groups(user_id):
    """Получить список групп пользователя с последним сообщением."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT g.id, g.name, g.created_by,
               gm_last.message as last_message,
               gm_last.created_at as last_message_time,
               gm_last.sender_id as last_message_sender_id
        FROM groups g
        JOIN group_members gm ON gm.group_id = g.id AND gm.user_id = ?
        LEFT JOIN group_messages gm_last ON gm_last.id = (
            SELECT id FROM group_messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1
        )
        ORDER BY COALESCE(gm_last.created_at, g.created_at) DESC
    ''', (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_group_messages(group_id, user_id):
    """Получить сообщения группы (только для участников)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    # Проверяем членство
    cursor.execute('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?', (group_id, user_id))
    if not cursor.fetchone():
        conn.close()
        return None
    cursor.execute('''
        SELECT gm.id, gm.sender_id, gm.message, gm.image_path, gm.created_at,
               u.username, u.phone
        FROM group_messages gm
        JOIN users u ON u.id = gm.sender_id
        WHERE gm.group_id = ?
        ORDER BY gm.created_at ASC
    ''', (group_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def send_group_message(group_id, sender_id, message=None, image_path=None):
    """Отправить сообщение в группу."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?', (group_id, sender_id))
    if not cursor.fetchone():
        conn.close()
        return None
    cursor.execute(
        'INSERT INTO group_messages (group_id, sender_id, message, image_path) VALUES (?, ?, ?, ?)',
        (group_id, sender_id, message, image_path)
    )
    msg_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return msg_id

def get_group_info(group_id, user_id):
    """Получить информацию о группе (только для участников)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM group_members WHERE group_id=? AND user_id=?', (group_id, user_id))
    if not cursor.fetchone():
        conn.close()
        return None
    cursor.execute('SELECT id, name, created_by, created_at FROM groups WHERE id=?', (group_id,))
    g = cursor.fetchone()
    if not g:
        conn.close()
        return None
    cursor.execute('''
        SELECT u.id, u.username, u.phone, u.avatar_path
        FROM group_members gm JOIN users u ON u.id = gm.user_id
        WHERE gm.group_id = ?
    ''', (group_id,))
    members = [dict(m) for m in cursor.fetchall()]
    conn.close()
    return {'id': g['id'], 'name': g['name'], 'created_by': g['created_by'], 'members': members}
