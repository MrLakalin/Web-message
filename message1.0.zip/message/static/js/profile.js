// Управление профилем пользователя
let currentProfile = null;
let isEditing = false;
let viewingOtherUserId = null;

async function loadProfile() {
    try {
        const response = await fetch('/api/profile');
        const data = await response.json();
        if (data.success) {
            currentProfile = data.profile;
            displayProfile(data.profile, true);
        }
    } catch (error) {
        console.error('Ошибка загрузки профиля:', error);
    }
}

function displayProfile(profile, isOwnProfile) {
    if (isOwnProfile === undefined) isOwnProfile = true;
    var avatarText = document.getElementById('profileAvatarText');
    var avatarImg = document.getElementById('profileAvatarImg');
    var username = document.getElementById('profileUsername');
    var usernameInput = document.getElementById('profileUsernameInput');
    var phoneId = document.getElementById('profilePhoneId');
    var profileEditBtn = document.getElementById('profileEditBtn');
    var profileAvatarUploadWrap = document.getElementById('profileAvatarUploadWrap');
    var profileBio = document.getElementById('profileBio');
    var profileBioInput = document.getElementById('profileBioInput');
    var profileOnlineStatus = document.getElementById('profileOnlineStatus');


    if (profile.avatar_path) {
        avatarImg.src = '/uploads/' + profile.avatar_path;
        avatarImg.style.display = 'block';
        avatarText.style.display = 'none';
    } else {
        avatarImg.style.display = 'none';
        avatarText.style.display = 'block';
        if (profile.phone && profile.phone.length >= 2) {
            avatarText.textContent = profile.phone.slice(-2);
        } else {
            avatarText.textContent = '--';
        }
    }

    username.textContent = profile.username || 'Не указан';
    usernameInput.value = profile.username || '';

    var uid = profile.user_id ? ' @' + profile.user_id : '';
    phoneId.textContent = profile.phone
        ? (profile.phone + uid)
        : (profile.user_id ? '@' + profile.user_id : '--');

    var bioText = profile.bio || '';
    if (profileBio) profileBio.textContent = bioText;
    if (profileBioInput) profileBioInput.value = bioText;

    if (profileOnlineStatus) {
        if (!isOwnProfile) {
            if (profile.online) {
                profileOnlineStatus.textContent = 'в сети';
                profileOnlineStatus.style.color = '#4caf50';
            } else if (profile.last_seen) {
                var dt = new Date(profile.last_seen);
                profileOnlineStatus.textContent = 'был(а) ' + dt.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
                profileOnlineStatus.style.color = '';
            } else {
                profileOnlineStatus.textContent = '';
            }
        } else {
            profileOnlineStatus.textContent = '';
        }
    }

    if (profileEditBtn) profileEditBtn.style.display = isOwnProfile ? '' : 'none';
    if (profileAvatarUploadWrap) profileAvatarUploadWrap.style.display = isOwnProfile ? 'block' : 'none';

    var profileActions = document.getElementById('profileActions');
    if (profileActions) profileActions.style.display = 'none';

    // Кнопка контакта — только для чужого профиля
    var profileContactWrap = document.getElementById('profileContactWrap');
    if (profileContactWrap) {
        if (!isOwnProfile && profile.id) {
            profileContactWrap.style.display = 'block';
            // Важно: передаем profile.id, а не viewingOtherUserId, чтобы быть уверенными
            loadContactStatus(profile.id);
        } else {
            profileContactWrap.style.display = 'none';
        }
    }
}


function openProfileModal() {
    viewingOtherUserId = null;
    var modal = document.getElementById('profileModal');
    modal.classList.add('show');
    loadProfile();
    isEditing = false;
    updateEditMode();
}

async function openUserProfileModal(userId) {
    if (!userId) return;
    viewingOtherUserId = userId;
    isEditing = false;
    var modal = document.getElementById('profileModal');
    try {
        var response = await fetch('/api/user/' + userId);
        var data = await response.json();
        if (data.success) {
            displayProfile(data.user, false);
            modal.classList.add('show');
        } else {
            if (typeof showToast === 'function') showToast('Не удалось загрузить профиль');
        }
    } catch (e) {
        console.error('Ошибка загрузки профиля пользователя:', e);
        if (typeof showToast === 'function') showToast('Ошибка загрузки профиля');
    }
}

function closeProfileModal() {
    viewingOtherUserId = null;
    var modal = document.getElementById('profileModal');
    modal.classList.remove('show');
    isEditing = false;
    updateEditMode();
    if (currentProfile) displayProfile(currentProfile, true);
}

function toggleEditMode() {
    isEditing = !isEditing;
    updateEditMode();
}

function updateEditMode() {
    var username = document.getElementById('profileUsername');
    var usernameInput = document.getElementById('profileUsernameInput');
    var actions = document.getElementById('profileActions');
    var profileBio = document.getElementById('profileBio');
    var profileBioInput = document.getElementById('profileBioInput');

    if (isEditing) {
        username.style.display = 'none';
        usernameInput.style.display = 'block';
        if (profileBio) profileBio.style.display = 'none';
        if (profileBioInput) profileBioInput.style.display = 'block';
        actions.style.display = 'flex';
        usernameInput.focus();
    } else {
        username.style.display = 'block';
        usernameInput.style.display = 'none';
        if (profileBio) profileBio.style.display = 'block';
        if (profileBioInput) profileBioInput.style.display = 'none';
        actions.style.display = 'none';
    }
}


async function saveProfile() {
    var usernameInput = document.getElementById('profileUsernameInput');
    var profileBioInput = document.getElementById('profileBioInput');
    var username = usernameInput.value.trim();
    var bio = profileBioInput ? profileBioInput.value.trim() : '';

    try {
        var response = await fetch('/api/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username || null })
        });
        var data = await response.json();

        if (!data.success) {
            alert('Ошибка обновления профиля: ' + (data.message || 'Неизвестная ошибка'));
            return;
        }

        var prevBio = (currentProfile && currentProfile.bio) || '';
        if (bio !== prevBio) {
            await fetch('/api/profile/bio', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ bio: bio })
            });
        }

        currentProfile = Object.assign({}, data.profile, { bio: bio });
        displayProfile(currentProfile, true);
        isEditing = false;
        updateEditMode();
        if (typeof showToast === 'function') showToast('Профиль обновлён');
    } catch (error) {
        console.error('Ошибка сохранения профиля:', error);
        alert('Ошибка соединения с сервером');
    }
}

function cancelEdit() {
    isEditing = false;
    updateEditMode();
    if (currentProfile) displayProfile(currentProfile, true);
}

async function loadContactStatus(userId) {
    var btn = document.getElementById('profileContactBtn');
    if (!btn) return;
    btn.textContent = '...';
    btn.disabled = true;
    try {
        var r = await fetch('/api/contacts/check?id=' + userId);
        var d = await r.json();
        setContactBtn(d.is_contact, userId);
    } catch(e) {
        console.error('Ошибка загрузки статуса контакта:', e);
        setContactBtn(false, userId);
    }
}

function setContactBtn(isContact, userId) {
    var btn = document.getElementById('profileContactBtn');
    if (!btn) return;
    btn.disabled = false;

    if (isContact) {
        btn.textContent = 'Удалить из контактов';
        btn.classList.remove('btn-add-contact');
        btn.classList.add('btn-remove-contact');
        btn.dataset.contactState = 'added';
    } else {
        btn.textContent = 'Добавить в контакты';
        btn.classList.remove('btn-remove-contact');
        btn.classList.add('btn-add-contact');
        btn.dataset.contactState = 'none';
    }
    btn.dataset.contactUserId = userId;
}

async function uploadAvatar(file) {
    if (!file) return;
    var formData = new FormData();
    formData.append('avatar', file);
    try {
        var r = await fetch('/api/profile/avatar', { method: 'POST', body: formData });
        var d = await r.json();
        if (d.success) {
            if (currentProfile) currentProfile.avatar_path = d.avatar_path;
            var avatarImg = document.getElementById('profileAvatarImg');
            var avatarText = document.getElementById('profileAvatarText');
            if (avatarImg) {
                avatarImg.src = '/uploads/' + d.avatar_path + '?t=' + Date.now();
                avatarImg.style.display = 'block';
                if (avatarText) avatarText.style.display = 'none';
            }
            if (typeof showToast === 'function') showToast('Фото обновлено');
        } else {
            if (typeof showToast === 'function') showToast('Ошибка загрузки фото');
        }
    } catch (e) {
        console.error('Ошибка загрузки аватара:', e);
        if (typeof showToast === 'function') showToast('Ошибка соединения');
    }
}


document.addEventListener('DOMContentLoaded', function() {
    var profileMenuItem = document.getElementById('profileMenuItem');
    if (profileMenuItem) {
        profileMenuItem.addEventListener('click', function(e) {
            e.stopPropagation();
            var menuDropdown = document.getElementById('menuDropdown');
            if (menuDropdown) menuDropdown.classList.remove('show');
            openProfileModal();
        });
    }

    var profileEditBtn = document.getElementById('profileEditBtn');
    if (profileEditBtn) profileEditBtn.addEventListener('click', toggleEditMode);

    var profileCloseBtn = document.getElementById('profileCloseBtn');
    if (profileCloseBtn) profileCloseBtn.addEventListener('click', closeProfileModal);

    var profileModalBackdrop = document.getElementById('profileModalBackdrop');
    if (profileModalBackdrop) profileModalBackdrop.addEventListener('click', closeProfileModal);

    var profileSaveBtn = document.getElementById('profileSaveBtn');
    if (profileSaveBtn) profileSaveBtn.addEventListener('click', saveProfile);

    var profileCancelBtn = document.getElementById('profileCancelBtn');
    if (profileCancelBtn) profileCancelBtn.addEventListener('click', cancelEdit);

    var profileAvatarBtn = document.getElementById('profileAvatarBtn');
    var profileAvatarInput = document.getElementById('profileAvatarInput');
    if (profileAvatarBtn && profileAvatarInput) {
        profileAvatarBtn.addEventListener('click', function() { profileAvatarInput.click(); });
        profileAvatarInput.addEventListener('change', function(e) {
            var file = e.target.files[0];
            if (file) uploadAvatar(file);
            profileAvatarInput.value = '';
        });
    }

    // Кнопка добавления/удаления из контактов
    var contactBtn = document.getElementById('profileContactBtn');
    if (contactBtn) {
        contactBtn.addEventListener('click', async function() {
            var userId = contactBtn.dataset.contactUserId;
            var state = contactBtn.dataset.contactState;
            
            if (!userId) {
                console.error('ID пользователя не найден');
                return;
            }
            
            console.log('Клик по кнопке контакта:', { userId, state }); // Для отладки
            
            contactBtn.disabled = true;
            contactBtn.textContent = '...';
            
            try {
                if (state === 'added') {
                    // Удаляем из контактов
                    console.log('Отправка DELETE запроса для удаления из контактов');
                    var r = await fetch('/api/contacts/' + userId, { 
                        method: 'DELETE',
                        headers: { 'Content-Type': 'application/json' }
                    });
                    var d = await r.json();
                    console.log('Ответ на DELETE:', d);
                    
                    if (d.success) {
                        setContactBtn(false, userId);
                        if (typeof showToast === 'function') showToast('Удалён из контактов');
                        if (typeof loadContacts === 'function') loadContacts();
                    } else {
                        throw new Error(d.message || 'Ошибка удаления');
                    }
                } else {
                    // Добавляем в контакты
                    console.log('Отправка POST запроса для добавления в контакты');
                    var r = await fetch('/api/contacts', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ contact_id: parseInt(userId) })
                    });
                    var d = await r.json();
                    console.log('Ответ на POST:', d);
                    
                    if (d.success) {
                        setContactBtn(true, userId);
                        if (typeof showToast === 'function') showToast('Добавлен в контакты');
                        if (typeof loadContacts === 'function') loadContacts();
                    } else {
                        throw new Error(d.message || 'Ошибка добавления');
                    }
                }
            } catch(e) {
                console.error('Ошибка контакта:', e);
                if (typeof showToast === 'function') showToast('Ошибка: ' + e.message);
                // Возвращаем кнопку в предыдущее состояние
                setContactBtn(state === 'added', userId);
            } finally {
                contactBtn.disabled = false;
            }
        });
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            var modal = document.getElementById('profileModal');
            if (modal && modal.classList.contains('show')) {
                if (isEditing) cancelEdit();
                else closeProfileModal();
            }
        }
    });

    var usernameInput = document.getElementById('profileUsernameInput');
    if (usernameInput) {
        usernameInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); saveProfile(); }
        });
    }
});