// Переменные для управления чатом
let currentChatUserId = null;
let messagesInterval = null;
let searchTimeout = null;
/** Предыдущее состояние чатов: id -> { last_message_time, last_message_sender_id } */
let previousChatsState = {};
// Переменные для работы с сообщениями
let selectedImage = null;
let imagePreview = null;

// Запись голосового сообщения
let voiceMediaRecorder = null;
let voiceChunks = [];
let voiceStream = null;
let voiceStartTime = null;
let voiceTimerInterval = null;

// Загрузка списка чатов (без показа загрузки)
async function loadChats() {
    const chatsList = document.getElementById('chatsList');
    if (!chatsList) return;

    // Сохраняем текущее состояние перед обновлением
    const activeUserId = currentChatUserId;
    const wasScrolled = chatsList.scrollTop;
    const hadContent = chatsList.querySelector('.user-item') || chatsList.querySelector('.empty-users');

    try {
        const response = await fetch('/api/chats');
        const data = await response.json();

        if (data.success) {
            if (data.chats.length === 0) {
                // Показываем пустое сообщение только если список действительно пуст
                if (!hadContent) {
                    chatsList.innerHTML = '<div class="empty-users">Нет чатов. Найдите пользователя для начала переписки.</div>';
                }
                previousChatsState = {};
                return;
            }

            // Проверяем новые входящие сообщения для уведомлений (только при обновлении, не при первой загрузке)
            const myId = Number(CURRENT_USER_ID);
            data.chats.forEach(chat => {
                const prev = previousChatsState[chat.id];
                const lastSender = chat.last_message_sender_id != null ? Number(chat.last_message_sender_id) : null;
                const isIncoming = lastSender !== myId && lastSender != null;
                const updated = prev && (String(prev.last_message_time) !== String(chat.last_message_time));
                if (isIncoming && updated) {
                    const raw = chat.last_message || '';
                    const msg = raw.slice(0, 50);
                    const txt = msg ? (msg + (raw.length > 50 ? '…' : '')) : 'Новое сообщение';
                    const senderName = chat.username || chat.phone;
                    showToast('Сообщение от ' + senderName + ': ' + txt);
                    showBrowserNotification('Flitt: ' + senderName, txt);
                }
                previousChatsState[chat.id] = {
                    last_message_time: chat.last_message_time,
                    last_message_sender_id: chat.last_message_sender_id
                };
            });

            // Быстро очищаем и обновляем без показа загрузки
            chatsList.innerHTML = '';

            data.chats.forEach(chat => {
                const chatItem = document.createElement('div');
                chatItem.className = 'user-item chat-item';
                chatItem.dataset.userId = chat.id;
                
                // Восстанавливаем активное состояние
                if (Number(chat.id) === Number(activeUserId)) {
                    chatItem.classList.add('active');
                    // Обновляем заголовок чата, если открыт чат с этим пользователем
                    const chatUserName = document.getElementById('chatUserName');
                    if (chatUserName) {
                        chatUserName.textContent = chat.username || chat.phone;
                    }
                }
                
                // Форматируем последнее сообщение для отображения
                let previewText = '';
                if (chat.last_message) {
                    const message = chat.last_message.trim();
                    if (message.length > 0) {
                        previewText = message.length > 40 ? message.substring(0, 40) + '...' : message;
                    }
                }
                
                // Определяем отображаемое имя: ник или номер телефона
                const displayName = chat.username || chat.phone;
                
                chatItem.innerHTML = `
                    <div class="user-avatar">
                        <span>${chat.phone.charAt(chat.phone.length - 2)}${chat.phone.charAt(chat.phone.length - 1)}</span>
                    </div>
                    <div class="user-details">
                        <span class="user-name">${displayName}</span>
                        ${previewText ? `<span class="chat-preview">${previewText}</span>` : '<span class="chat-preview" style="opacity: 0.5;">Нет сообщений</span>'}
                    </div>
                    ${(chat.unread || 0) > 0 ? `<span class="unread-badge">${chat.unread > 99 ? '99+' : chat.unread}</span>` : ''}
                `;
                // Добавляем обработчики для клика и тача
                const handleChatOpen = (e) => {
                    e.stopPropagation();
                    openChat(chat.id, chat.phone, chat.username);
                };
                chatItem.addEventListener('click', handleChatOpen);
                chatItem.addEventListener('touchend', handleChatOpen, { passive: true });
                chatsList.appendChild(chatItem);
            });
            
            // Восстанавливаем позицию прокрутки только если был контент
            if (hadContent) {
                chatsList.scrollTop = wasScrolled;
            }
        }
    } catch (error) {
        console.error('Ошибка загрузки чатов:', error);
        // Не показываем ошибку при автоматических обновлениях
    }
}

// Тихая загрузка чатов (алиас для единообразия)
async function silentLoadChats() {
    await loadChats();
}

// Показать in-app тост
function showToast(text) {
    const container = document.getElementById('notificationsContainer');
    if (!container) return;
    const el = document.createElement('div');
    el.className = 'notification-toast';
    el.textContent = text;
    container.appendChild(el);
    setTimeout(() => el.remove(), 4000);
}

// Показать браузерное уведомление (если вкладка не в фокусе)
function showBrowserNotification(title, body) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    if (!document.hidden) return; // тост уже показываем
    try {
        const n = new Notification(title, { body });
        n.onclick = () => { n.close(); window.focus(); };
        setTimeout(() => n.close(), 4000);
    } catch (e) {}
}

// Запросить разрешение на уведомления
function requestNotificationPermission() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

// Поиск пользователей по номеру
async function searchUsers(searchQuery) {
    const usersList = document.getElementById('usersList');
    const chatsList = document.getElementById('chatsList');

    const cleanQuery = searchQuery.trim();

    if (cleanQuery.length === 0) {
        usersList.style.display = 'none';
        chatsList.style.display = 'flex';
        loadChats();
        return;
    }

    chatsList.style.display = 'none';
    usersList.style.display = 'flex';

    try {
        const response = await fetch(`/api/users/search?q=${encodeURIComponent(cleanQuery)}`);
        const data = await response.json();

        if (data.success) {
            if (data.users.length === 0) {
                usersList.innerHTML = '<div class="empty-users">Пользователи не найдены</div>';
                return;
            }

            usersList.innerHTML = '';
            data.users.forEach(user => {
                const userItem = document.createElement('div');
                userItem.className = 'user-item';
                userItem.dataset.userId = user.id;

                const displayName = user.username || user.phone;
                const uid = user.user_id || '';
                const initials = uid.slice(0, 2).toUpperCase() || String(user.id).slice(-2);

                userItem.innerHTML = `
                    <div class="user-avatar">
                        <span>${initials}</span>
                    </div>
                    <div class="user-details">
                        <span class="user-name">${displayName}</span>
                        <span class="chat-preview">@${uid}</span>
                    </div>
                `;
                const handleUserOpen = (e) => {
                    e.stopPropagation();
                    openChat(user.id, user.phone, user.username);
                };
                userItem.addEventListener('click', handleUserOpen);
                userItem.addEventListener('touchend', handleUserOpen, { passive: true });
                usersList.appendChild(userItem);
            });
        } else {
            usersList.innerHTML = '<div class="error-users">Ошибка поиска</div>';
        }
    } catch (error) {
        console.error('Ошибка поиска пользователей:', error);
        usersList.innerHTML = '<div class="error-users">Ошибка соединения</div>';
    }
}

// Открытие чата с пользователем
async function openChat(userId, userPhone, username = null) {
    if (!userId || !userPhone) {
        console.error('openChat: неверные параметры', userId, userPhone);
        return;
    }
    
    currentChatUserId = userId;
    currentGroupId = null; // сбрасываем группу
    if (groupMessagesInterval) { clearInterval(groupMessagesInterval); groupMessagesInterval = null; }
    
    // Обновление UI
    const placeholder = document.getElementById('chatPlaceholder');
    const chatWindow = document.getElementById('chatWindow');
    const chatUserName = document.getElementById('chatUserName');
    const chatUserAvatarText = document.getElementById('chatUserAvatarText');
    
    if (placeholder) placeholder.style.display = 'none';
    if (chatWindow) chatWindow.style.display = 'flex';

    if (chatUserName) chatUserName.textContent = username || userPhone;

    if (chatUserAvatarText && userPhone.length >= 2) {
        chatUserAvatarText.textContent = userPhone.slice(-2);
    }

    // Загружаем онлайн статус
    loadUserStatus(userId);

    document.querySelectorAll('.user-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.userId == userId) item.classList.add('active');
    });

    if (window.innerWidth <= 768) {
        document.getElementById('usersSidebar').classList.add('hidden');
        document.getElementById('chatArea').classList.add('fullscreen');
    }

    await loadMessages(userId, true);

    if (messagesInterval) clearInterval(messagesInterval);
    messagesInterval = setInterval(() => loadMessages(userId), 1000);

    // Обновляем статус каждые 30 сек
    if (window._statusInterval) clearInterval(window._statusInterval);
    window._statusInterval = setInterval(() => loadUserStatus(userId), 30000);

    document.getElementById('messageInput').focus();
}

async function loadUserStatus(userId) {
    try {
        const r = await fetch(`/api/user/${userId}/status`);
        const d = await r.json();
        const el = document.getElementById('chatUserStatus');
        if (!el) return;
        if (d.online) {
            el.textContent = 'в сети';
            el.className = 'chat-user-status online';
        } else if (d.last_seen) {
            const dt = new Date(d.last_seen);
            el.textContent = 'был(а) ' + dt.toLocaleTimeString('ru', {hour:'2-digit', minute:'2-digit'});
            el.className = 'chat-user-status';
        } else {
            el.textContent = '';
        }
    } catch(e) {}
}

// Загрузка сообщений
async function loadMessages(userId, scrollToBottom = false) {
    try {
        const response = await fetch(`/api/messages?user_id=${userId}`);
        const data = await response.json();

        if (data.success) {
            displayMessages(data.messages, scrollToBottom);
        }
    } catch (error) {
        console.error('Ошибка загрузки сообщений:', error);
    }
}

// Отображение сообщений
function displayMessages(messages, scrollToBottom = true) {
    const messagesContainer = document.getElementById('chatMessages');
    if (!messagesContainer) return;

    const wasAtBottom = messagesContainer.scrollHeight - messagesContainer.scrollTop <= messagesContainer.clientHeight + 100;
    const oldScrollHeight = messagesContainer.scrollHeight;

    const msgMap = {};
    messages.forEach(m => { msgMap[m.id] = m; });

    messagesContainer.innerHTML = '';

    if (messages.length === 0) {
        messagesContainer.innerHTML = '<div class="empty-chat">Пока нет сообщений. Начните переписку!</div>';
        return;
    }

    let lastDate = null;
    messages.forEach((msg, index) => {
        const msgDate = new Date(msg.created_at);
        const currentDate = msgDate.toDateString();

        if (lastDate !== currentDate) {
            const dateSeparator = document.createElement('div');
            dateSeparator.className = 'message-date-separator';
            const dateText = formatDate(msgDate);
            dateSeparator.innerHTML = `<span>${dateText}</span>`;
            messagesContainer.appendChild(dateSeparator);
            lastDate = currentDate;
        }

        const messageDiv = document.createElement('div');
        const isSent = Number(msg.sender_id) === Number(CURRENT_USER_ID);
        messageDiv.className = `message ${isSent ? 'message-sent' : 'message-received'}`;
        messageDiv.dataset.messageId = msg.id;

        let messageLongPressTimer = null;
        messageDiv.addEventListener('contextmenu', (e) => {
            if (typeof window.handleContextMenu === 'function') {
                window.handleContextMenu(e, msg, messageDiv);
            }
        });
        messageDiv.addEventListener('touchstart', (e) => {
            if (typeof window.handleLongPressStart === 'function') {
                window.handleLongPressStart(e, msg, messageDiv);
            }
        });
        messageDiv.addEventListener('touchend', (e) => {
            if (typeof window.handleLongPressEnd === 'function') {
                window.handleLongPressEnd(e);
            }
            if (messageLongPressTimer) {
                clearTimeout(messageLongPressTimer);
                messageLongPressTimer = null;
            }
        });
        messageDiv.addEventListener('touchmove', (e) => {
            if (messageLongPressTimer) {
                clearTimeout(messageLongPressTimer);
                messageLongPressTimer = null;
            }
            if (typeof window.handleLongPressEnd === 'function') {
                window.handleLongPressEnd(e);
            }
        });

        const messageBubble = document.createElement('div');
        messageBubble.className = 'message-bubble';

        // Цитата ответа (как на картинке 2 — вертикальная полоска слева)
        if (msg.reply_to_id && msgMap[msg.reply_to_id]) {
            const replyMsg = msgMap[msg.reply_to_id];
            const replyAuthor = Number(replyMsg.sender_id) === Number(CURRENT_USER_ID) ? 'Вы' : 'Собеседник';
            const replyText = (replyMsg.message || '').trim() || '📷 Фото';
            const replyShort = replyText.length > 60 ? replyText.slice(0, 60) + '…' : replyText;
            const replyQuote = document.createElement('div');
            replyQuote.className = 'message-reply-quote';
            replyQuote.innerHTML = `<span class="message-reply-author">${escapeHtmlForPreview(replyAuthor)}</span><span class="message-reply-text">${escapeHtmlForPreview(replyShort)}</span>`;
            messageBubble.appendChild(replyQuote);
        }

        if (msg.voice_path) {
            const voiceWrap = document.createElement('div');
            voiceWrap.className = 'message-voice';
            const durationSec = msg.voice_duration_sec != null ? Number(msg.voice_duration_sec) : 0;
            const voiceUrl = '/uploads/' + encodeURIComponent(msg.voice_path);
            const playBtn = document.createElement('button');
            playBtn.type = 'button';
            playBtn.className = 'message-voice-play';
            playBtn.dataset.voiceUrl = voiceUrl;
            playBtn.setAttribute('aria-label', 'Воспроизвести');
            playBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>';
            playBtn.addEventListener('click', function () {
                var url = this.dataset.voiceUrl;
                if (!url) return;
                if (window._currentVoiceAudio && window._currentVoiceAudio.src === (window.location.origin + url)) {
                    if (!window._currentVoiceAudio.paused) {
                        window._currentVoiceAudio.pause();
                        return;
                    }
                }
                var audio = new Audio(url);
                window._currentVoiceAudio = audio;
                audio.play().catch(function (e) {
                    console.error('Ошибка воспроизведения:', e);
                    if (typeof showToast === 'function') showToast('Не удалось воспроизвести');
                });
            });
            voiceWrap.appendChild(playBtn);
            const content = document.createElement('div');
            content.className = 'message-voice-content';
            const waveform = document.createElement('div');
            waveform.className = 'message-voice-waveform';
            for (let i = 0; i < 24; i++) {
                const bar = document.createElement('span');
                bar.style.height = (8 + Math.abs(Math.sin((msg.id + i) * 0.4) * 12)) + 'px';
                waveform.appendChild(bar);
            }
            content.appendChild(waveform);
            const durationEl = document.createElement('div');
            durationEl.className = 'message-voice-duration';
            durationEl.textContent = formatVoiceDuration(durationSec);
            content.appendChild(durationEl);
            voiceWrap.appendChild(content);
            messageBubble.appendChild(voiceWrap);
        }

        if (msg.image_path) {
            const imageContainer = document.createElement('div');
            imageContainer.className = 'message-image-container';
            const img = document.createElement('img');
            img.src = `/uploads/${msg.image_path}`;
            img.alt = 'Изображение';
            img.className = 'message-image';
            img.loading = 'lazy';
            imageContainer.appendChild(img);
            messageBubble.appendChild(imageContainer);
        }

        if (msg.message) {
            const messageText = document.createElement('div');
            messageText.className = 'message-text-content';
            messageText.textContent = msg.message;
            messageBubble.appendChild(messageText);
        }

        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        let timeHtml = formatTime(msg.created_at);
        // Галочки прочитано (только для отправленных)
        if (isSent) {
            const tick = msg.is_read
                ? '<span class="message-read-tick read" title="Прочитано">✓✓</span>'
                : '<span class="message-read-tick" title="Доставлено">✓</span>';
            timeHtml += tick;
        }
        messageTime.innerHTML = timeHtml;

        messageDiv.appendChild(messageBubble);
        messageDiv.appendChild(messageTime);

        // Реакции
        if (msg.reactions && Object.keys(msg.reactions).length > 0) {
            const reactionsEl = document.createElement('div');
            reactionsEl.className = 'message-reactions';
            Object.entries(msg.reactions).forEach(([emoji, count]) => {
                const chip = document.createElement('span');
                const isMine = msg.my_reactions && msg.my_reactions.includes(emoji);
                chip.className = 'reaction-chip' + (isMine ? ' my-reaction' : '');
                chip.innerHTML = `${emoji}<span class="reaction-count">${count}</span>`;
                chip.addEventListener('click', () => sendReaction(msg.id, emoji));
                reactionsEl.appendChild(chip);
            });
            messageDiv.appendChild(reactionsEl);
        }

        // Двойной клик для emoji picker
        attachReactionListener(messageDiv, msg);

        messagesContainer.appendChild(messageDiv);
    });

    // Прокрутка вниз только если нужно или пользователь был внизу
    if (scrollToBottom || wasAtBottom) {
        // Используем requestAnimationFrame для плавной прокрутки
        requestAnimationFrame(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        });
    } else {
        // Сохраняем позицию прокрутки при обновлении
        const newScrollHeight = messagesContainer.scrollHeight;
        const scrollDiff = newScrollHeight - oldScrollHeight;
        messagesContainer.scrollTop += scrollDiff;
    }
}

function escapeHtmlForPreview(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Форматирование времени
function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

// Форматирование даты
function formatDate(date) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const messageDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    
    if (messageDate.getTime() === today.getTime()) {
        return 'Сегодня';
    } else if (messageDate.getTime() === yesterday.getTime()) {
        return 'Вчера';
    } else {
        return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined });
    }
}

// Форматирование длительности голосового (секунды -> "0:19")
function formatVoiceDuration(sec) {
    if (sec == null || isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
}

// Обновление таймера записи (0:00,00)
function updateVoiceRecordingTimer() {
    const el = document.getElementById('voiceRecordingTimer');
    if (!el || !voiceStartTime) return;
    const ms = Date.now() - voiceStartTime;
    const totalSec = ms / 1000;
    const min = Math.floor(totalSec / 60);
    const sec = Math.floor(totalSec % 60);
    const cent = Math.floor((ms % 1000) / 10);
    el.textContent = `${min}:${sec.toString().padStart(2, '0')},${cent.toString().padStart(2, '0')}`;
}

function stopVoiceRecordingUI() {
    if (voiceTimerInterval) {
        clearInterval(voiceTimerInterval);
        voiceTimerInterval = null;
    }
    voiceStartTime = null;
    const form = document.getElementById('messageForm');
    const bar = document.getElementById('voiceRecordingBar');
    if (form) form.style.display = 'flex';
    if (bar) bar.style.display = 'none';
    if (voiceStream) {
        voiceStream.getTracks().forEach(t => t.stop());
        voiceStream = null;
    }
}

async function startVoiceRecording() {
    if (!currentChatUserId) {
        if (typeof showToast === 'function') showToast('Выберите чат');
        return;
    }
    var isSecure = window.isSecureContext || window.location.protocol === 'https:' || /localhost|127\.0\.0\.1/i.test(window.location.hostname);
    if (!isSecure) {
        if (typeof showToast === 'function') showToast('Для записи голоса откройте сайт по HTTPS или с localhost');
        return;
    }
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
        if (typeof showToast === 'function') showToast('Ваш браузер не поддерживает запись с микрофона');
        return;
    }
    if (typeof showToast === 'function') showToast('Разрешите доступ к микрофону в окне браузера');
    try {
        voiceStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        voiceMediaRecorder = new MediaRecorder(voiceStream);
        voiceChunks = [];
        voiceMediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) voiceChunks.push(e.data); };
        voiceMediaRecorder.start(200);
        voiceStartTime = Date.now();
        document.getElementById('messageForm').style.display = 'none';
        document.getElementById('voiceRecordingBar').style.display = 'flex';
        updateVoiceRecordingTimer();
        voiceTimerInterval = setInterval(updateVoiceRecordingTimer, 100);
    } catch (err) {
        console.error('Ошибка доступа к микрофону:', err);
        let msg = 'Нет доступа к микрофону';
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
            msg = 'Разрешите микрофон: нажмите на замок или «i» в адресной строке и включите микрофон для этого сайта';
        } else if (err.name === 'NotFoundError') {
            msg = 'Микрофон не найден. Подключите микрофон и обновите страницу';
        } else if (err.name === 'NotReadableError') {
            msg = 'Микрофон занят другим приложением. Закройте другие вкладки и попробуйте снова';
        }
        if (typeof showToast === 'function') showToast(msg);
    }
}

function cancelVoiceRecording() {
    if (voiceMediaRecorder && voiceMediaRecorder.state !== 'inactive') {
        voiceMediaRecorder.stop();
    }
    voiceChunks = [];
    voiceMediaRecorder = null;
    stopVoiceRecordingUI();
}

function sendVoiceRecording() {
    if (!voiceMediaRecorder || voiceChunks.length === 0) {
        stopVoiceRecordingUI();
        return;
    }
    voiceMediaRecorder.onstop = async () => {
        const durationSec = (Date.now() - voiceStartTime) / 1000;
        const blob = new Blob(voiceChunks, { type: voiceMediaRecorder.mimeType || 'audio/webm' });
        const file = new File([blob], 'voice.webm', { type: blob.type });
        voiceChunks = [];
        voiceMediaRecorder = null;
        stopVoiceRecordingUI();
        try {
            const formData = new FormData();
            formData.append('receiver_id', currentChatUserId);
            formData.append('voice', file);
            formData.append('voice_duration_sec', durationSec.toFixed(2));
            const response = await fetch('/api/messages', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                if (typeof showToast === 'function') showToast('Голосовое отправлено');
                await silentLoadChats();
                await loadMessages(currentChatUserId, true);
            } else {
                if (typeof showToast === 'function') showToast('Ошибка: ' + (data.message || ''));
            }
        } catch (e) {
            console.error(e);
            if (typeof showToast === 'function') showToast('Ошибка отправки');
        }
    };
    voiceMediaRecorder.stop();
}

// Управление видимостью кнопок ввода
function updateInputButtons() {
    const messageInput = document.getElementById('messageInput');
    const messageForm = document.getElementById('messageForm');
    if (!messageInput || !messageForm) return;
    
    const hasText = messageInput.value.trim().length > 0;
    const hasImage = selectedImage !== null;
    
    if (hasText || hasImage) {
        messageForm.classList.add('has-text');
    } else {
        messageForm.classList.remove('has-text');
    }
}

// Отправка сообщения
const messageForm = document.getElementById('messageForm');
if (messageForm) {
    messageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!currentChatUserId) return;

        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();

        // Проверяем, редактируем ли мы сообщение
        if (window.editingMessageId) {
            try {
                const response = await fetch(`/api/messages/${window.editingMessageId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message
                    })
                });

                const data = await response.json();
                
                if (data.success) {
                    messageInput.value = '';
                    messageInput.placeholder = 'Сообщение...';
                    window.editingMessageId = null;
                    updateInputButtons();
                    if (typeof showToast === 'function') {
                        showToast('Сообщение изменено');
                    }
                    // Перезагружаем сообщения
                    await loadMessages(currentChatUserId, false);
                } else {
                    alert('Ошибка изменения сообщения: ' + (data.message || 'Неизвестная ошибка'));
                }
            } catch (error) {
                console.error('Ошибка изменения сообщения:', error);
                alert('Ошибка соединения с сервером');
            }
            return;
        }

        if (!message && !selectedImage) return;

        try {
            const formData = new FormData();
            formData.append('receiver_id', currentChatUserId);
            if (message) {
                formData.append('message', message);
            }
            if (selectedImage) {
                formData.append('image', selectedImage);
            }
            // Добавляем reply_to_id, если отвечаем на сообщение
            if (window.replyToMessage && typeof window.replyToMessage !== 'undefined') {
                formData.append('reply_to_id', window.replyToMessage.id);
            }

            const response = await fetch('/api/messages', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            
            if (data.success) {
                messageInput.value = '';
                messageInput.placeholder = 'Сообщение...';
                selectedImage = null;
                window.replyToMessage = null;
                if (imagePreview) {
                    imagePreview.remove();
                    imagePreview = null;
                }
                updateInputButtons();
                // Сначала обновляем список чатов, чтобы чат стал первым
                await silentLoadChats();
                // Затем перезагружаем сообщения (прокрутка вниз после отправки)
                await loadMessages(currentChatUserId, true);
            } else {
                alert('Ошибка отправки сообщения: ' + (data.message || 'Неизвестная ошибка'));
            }
        } catch (error) {
            console.error('Ошибка отправки сообщения:', error);
            alert('Ошибка соединения с сервером');
        }
    });
    
    // Отслеживание изменений в поле ввода
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        messageInput.addEventListener('input', updateInputButtons);
        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                messageForm.dispatchEvent(new Event('submit'));
            }
        });
    }
}

// Кнопка "Назад" для мобильных устройств
const backBtn = document.getElementById('backBtn');
if (backBtn) {
    backBtn.addEventListener('click', () => {
        // На мобильных устройствах показываем список и скрываем чат
        if (window.innerWidth <= 768) {
            document.getElementById('usersSidebar').classList.remove('hidden');
            document.getElementById('chatArea').classList.remove('fullscreen');
            document.getElementById('chatPlaceholder').style.display = 'flex';
            document.getElementById('chatWindow').style.display = 'none';
        }

        // Останавливаем автообновление
        if (messagesInterval) {
            clearInterval(messagesInterval);
            messagesInterval = null;
        }

        currentChatUserId = null;

        // Снимаем выделение активного пользователя
        document.querySelectorAll('.user-item').forEach(item => {
            item.classList.remove('active');
        });
    });
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Загружаем список чатов (тихо, без индикаторов)
    loadChats();
    loadGroups();

    // ─── ВКЛАДКИ ЧАТЫ / КОНТАКТЫ ─────────────────────────────────────────
    const tabChats = document.getElementById('tabChats');
    const tabContacts = document.getElementById('tabContacts');
    const chatsList = document.getElementById('chatsList');
    const contactsList = document.getElementById('contactsList');

    function switchTab(tab) {
        if (tab === 'contacts') {
            tabChats.classList.remove('active');
            tabContacts.classList.add('active');
            chatsList.style.display = 'none';
            contactsList.style.display = 'flex';
            document.getElementById('usersList').style.display = 'none';
            loadContacts();
        } else {
            tabContacts.classList.remove('active');
            tabChats.classList.add('active');
            contactsList.style.display = 'none';
            chatsList.style.display = 'flex';
        }
    }

    if (tabChats) tabChats.addEventListener('click', () => switchTab('chats'));
    if (tabContacts) tabContacts.addEventListener('click', () => switchTab('contacts'));
    
    // Обработчики для новых кнопок
    const attachBtn = document.getElementById('attachBtn');
    const fileInput = document.getElementById('fileInput');
    
    if (attachBtn && fileInput) {
        attachBtn.addEventListener('click', () => {
            fileInput.click();
        });
        
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (!file.type.startsWith('image/')) {
                    alert('Пожалуйста, выберите изображение');
                    return;
                }
                
                selectedImage = file;
                
                // Показываем превью изображения
                if (imagePreview) {
                    imagePreview.remove();
                }
                
                const reader = new FileReader();
                reader.onload = (e) => {
                    imagePreview = document.createElement('div');
                    imagePreview.className = 'image-preview';
                    imagePreview.innerHTML = `
                        <img src="${e.target.result}" alt="Preview">
                        <button type="button" class="image-preview-remove" aria-label="Удалить">×</button>
                    `;
                    
                    const messageForm = document.getElementById('messageForm');
                    messageForm.parentElement.insertBefore(imagePreview, messageForm);
                    
                    // Кнопка удаления превью
                    const removeBtn = imagePreview.querySelector('.image-preview-remove');
                    removeBtn.addEventListener('click', () => {
                        selectedImage = null;
                        imagePreview.remove();
                        imagePreview = null;
                        fileInput.value = '';
                    });
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    const emojiBtn = document.getElementById('emojiBtn');
    if (emojiBtn) {
        emojiBtn.addEventListener('click', () => {
            // TODO: Реализовать выбор эмодзи
            console.log('Эмодзи (пока не реализовано)');
        });
    }

    const voiceBtn = document.getElementById('voiceBtn');
    if (voiceBtn) {
        voiceBtn.addEventListener('click', (e) => {
            e.preventDefault();
            startVoiceRecording();
        });
    }
    const voiceRecordingDelete = document.getElementById('voiceRecordingDelete');
    if (voiceRecordingDelete) {
        voiceRecordingDelete.addEventListener('click', () => cancelVoiceRecording());
    }
    const voiceRecordingSend = document.getElementById('voiceRecordingSend');
    if (voiceRecordingSend) {
        voiceRecordingSend.addEventListener('click', () => sendVoiceRecording());
    }

    const chatHeaderProfile = document.getElementById('chatHeaderProfile');
    if (chatHeaderProfile) {
        chatHeaderProfile.addEventListener('click', () => {
            if (currentChatUserId && typeof openUserProfileModal === 'function') {
                openUserProfileModal(currentChatUserId);
            }
        });
        chatHeaderProfile.addEventListener('keydown', (e) => {
            if ((e.key === 'Enter' || e.key === ' ') && currentChatUserId && typeof openUserProfileModal === 'function') {
                e.preventDefault();
                openUserProfileModal(currentChatUserId);
            }
        });
    }

    const menuBtnChat = document.getElementById('menuBtnChat');
    if (menuBtnChat) {
        menuBtnChat.addEventListener('click', () => {
            // TODO: Реализовать меню чата
            console.log('Меню чата (пока не реализовано)');
        });
    }
    
    // Инициализация кнопок ввода
    updateInputButtons();
    
    // Обработка меню
    const menuBtn = document.getElementById('menuBtn');
    const menuDropdown = document.getElementById('menuDropdown');
    const logoutMenuItem = document.getElementById('logoutMenuItem');
    
    if (menuBtn && menuDropdown) {
        menuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            menuDropdown.classList.toggle('show');
        });
        document.addEventListener('click', (e) => {
            if (!menuBtn.contains(e.target) && !menuDropdown.contains(e.target)) {
                menuDropdown.classList.remove('show');
            }
        });
    }

    // Тема — теперь в настройках
    const themeToggle = document.getElementById('themeToggle');
    const themeToggleText = document.getElementById('themeToggleText');
    function applyTheme(theme) {
        if (theme === 'light') {
            document.body.classList.remove('theme-dark');
            document.body.classList.add('theme-light');
            if (themeToggleText) themeToggleText.textContent = 'Тёмная тема';
        } else {
            document.body.classList.remove('theme-light');
            document.body.classList.add('theme-dark');
            if (themeToggleText) themeToggleText.textContent = 'Светлая тема';
        }
    }
    applyTheme(localStorage.getItem('theme') || 'dark');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const isLight = document.body.classList.contains('theme-light');
            const next = isLight ? 'dark' : 'light';
            localStorage.setItem('theme', next);
            applyTheme(next);
        });
    }

    // Настройки
    function openInfoModal(id) {
        const menuDropdown = document.getElementById('menuDropdown');
        if (menuDropdown) menuDropdown.classList.remove('show');
        const modal = document.getElementById(id);
        if (modal) modal.classList.add('show');
    }
    function closeInfoModal(id) {
        const modal = document.getElementById(id);
        if (modal) modal.classList.remove('show');
    }

    ['settings', 'userGuide', 'terms', 'aboutApp'].forEach(name => {
        const btn = document.getElementById(name + 'MenuItem');
        if (btn) btn.addEventListener('click', () => openInfoModal(name + 'Modal'));
        const closeBtn = document.getElementById(name + 'ModalClose');
        if (closeBtn) closeBtn.addEventListener('click', () => closeInfoModal(name + 'Modal'));
        const backdrop = document.getElementById(name + 'ModalBackdrop');
        if (backdrop) backdrop.addEventListener('click', () => closeInfoModal(name + 'Modal'));
    });

    // Кнопка "О приложении" внутри настроек
    const aboutAppBtn = document.getElementById('aboutAppBtn');
    if (aboutAppBtn) {
        aboutAppBtn.addEventListener('click', () => {
            closeInfoModal('settingsModal');
            openInfoModal('aboutAppModal');
        });
    }

    // Уведомления в настройках
    const notifRow = document.getElementById('notifToggleRow');
    if (notifRow) {
        notifRow.addEventListener('click', () => {
            if (!('Notification' in window)) { showToast('Браузер не поддерживает уведомления'); return; }
            if (Notification.permission === 'granted') {
                showToast('Уведомления уже включены');
            } else {
                Notification.requestPermission().then(p => {
                    showToast(p === 'granted' ? 'Уведомления включены' : 'Уведомления отклонены');
                });
            }
        });
    }    
    // Обработка выхода из аккаунта
    if (logoutMenuItem) {
        logoutMenuItem.addEventListener('click', async () => {
            try {
                const response = await fetch('/api/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                
                const data = await response.json();
                if (data.success) {
                    window.location.href = data.redirect || '/login';
                }
            } catch (error) {
                console.error('Ошибка выхода:', error);
            }
        });
    }
    
    const searchInput = document.getElementById('searchInput');
    
    if (searchInput) {
        // Поиск с задержкой (debounce)
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            if (searchTimeout) {
                clearTimeout(searchTimeout);
            }
            
            if (query.length === 0) {
                // Если поиск пустой, показываем список чатов
                document.getElementById('usersList').style.display = 'none';
                document.getElementById('chatsList').style.display = 'flex';
                loadChats();
                return;
            }
            
            searchTimeout = setTimeout(() => {
                searchUsers(query);
            }, 300); // Задержка 300мс перед поиском
        });
    }
    
    // Кнопка прокрутки вниз
    const scrollToBottomBtn = document.getElementById('scrollToBottomBtn');
    const chatMessages = document.getElementById('chatMessages');

    if (scrollToBottomBtn && chatMessages) {
        // Показываем кнопку когда пользователь прокрутил вверх
        chatMessages.addEventListener('scroll', () => {
            const distanceFromBottom = chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight;
            if (distanceFromBottom > 150) {
                scrollToBottomBtn.style.display = 'flex';
                requestAnimationFrame(() => scrollToBottomBtn.classList.add('visible'));
            } else {
                scrollToBottomBtn.classList.remove('visible');
                setTimeout(() => {
                    if (!scrollToBottomBtn.classList.contains('visible')) {
                        scrollToBottomBtn.style.display = 'none';
                    }
                }, 200);
            }
        });

        // Клик — прокрутка вниз
        scrollToBottomBtn.addEventListener('click', () => {
            chatMessages.scrollTo({ top: chatMessages.scrollHeight, behavior: 'smooth' });
        });
    }

    // Автообновление списка чатов каждую секунду (тихо, без визуальных индикаторов)
    setInterval(() => {
        const searchInput = document.getElementById('searchInput');
        if (!currentChatUserId && !currentGroupId && (!searchInput || searchInput.value.trim() === '')) {
            // Показываем список чатов, если он скрыт
            const chatsList = document.getElementById('chatsList');
            const usersList = document.getElementById('usersList');
            if (chatsList && usersList && usersList.style.display !== 'flex') {
                chatsList.style.display = 'flex';
                usersList.style.display = 'none';
                silentLoadChats();
            } else if (chatsList && chatsList.style.display === 'flex') {
                silentLoadChats();
            }
        }
    }, 1000);
});

// Обработка изменения размера окна
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        // На десктопе всегда показываем обе колонки
        document.getElementById('usersSidebar').classList.remove('hidden');
        document.getElementById('chatArea').classList.remove('fullscreen');
    }
});

// Предотвращение скролла всего контейнера при открытии клавиатуры на мобильных
if (window.innerWidth <= 768) {
    // Предотвращаем скролл body и html
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
    
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        let lastScrollTop = 0;
        
        messageInput.addEventListener('focus', (e) => {
            // Сохраняем текущую позицию скролла
            lastScrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Предотвращаем скролл body
            window.scrollTo(0, lastScrollTop);
            
            // Прокручиваем сообщения вниз после небольшой задержки (когда клавиатура откроется)
            setTimeout(() => {
                const messagesContainer = document.getElementById('chatMessages');
                if (messagesContainer) {
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }
                // Убеждаемся, что body не скроллится
                window.scrollTo(0, lastScrollTop);
            }, 100);
            
            setTimeout(() => {
                window.scrollTo(0, lastScrollTop);
            }, 300);
        }, { passive: false });

        // Предотвращаем скролл при вводе
        messageInput.addEventListener('touchstart', (e) => {
            e.stopPropagation();
        }, { passive: true });
        
        // Предотвращаем скролл при изменении размера viewport (открытие клавиатуры)
        window.addEventListener('resize', () => {
            if (document.activeElement === messageInput) {
                window.scrollTo(0, lastScrollTop);
            }
        });
    }

    // Предотвращаем скролл при касании области сообщений
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) {
        chatMessages.addEventListener('touchmove', (e) => {
            // Разрешаем скролл только внутри chat-messages
            e.stopPropagation();
        }, { passive: true });
    }

    // Предотвращаем скролл всего контейнера, но разрешаем клики
    const messengerContainer = document.querySelector('.messenger-container');
    if (messengerContainer) {
        messengerContainer.addEventListener('touchmove', (e) => {
            // Если скролл происходит не в chat-messages и не в списках чатов, предотвращаем его
            if (!e.target.closest('.chat-messages') && 
                !e.target.closest('.chat-input-container') && 
                !e.target.closest('.chats-list') && 
                !e.target.closest('.users-list')) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // НЕ блокируем touchstart, чтобы клики работали
    }
}

// ─── РЕАКЦИИ ────────────────────────────────────────────────────────────────

async function sendReaction(messageId, emoji) {
    try {
        await fetch(`/api/messages/${messageId}/react`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ emoji })
        });
        if (currentChatUserId) await loadMessages(currentChatUserId, false);
    } catch(e) { console.error('Ошибка реакции:', e); }
}

// Emoji picker — показываем над сообщением
let emojiPickerTarget = null;
function showEmojiPicker(messageId, anchorEl) {
    const picker = document.getElementById('emojiReactionPicker');
    if (!picker) return;
    emojiPickerTarget = messageId;
    const rect = anchorEl.getBoundingClientRect();
    picker.style.display = 'flex';
    picker.style.top = (rect.top - 56 + window.scrollY) + 'px';
    picker.style.left = Math.min(rect.left, window.innerWidth - 280) + 'px';
}

function hideEmojiPicker() {
    const picker = document.getElementById('emojiReactionPicker');
    if (picker) picker.style.display = 'none';
    emojiPickerTarget = null;
}

document.addEventListener('DOMContentLoaded', () => {
    const picker = document.getElementById('emojiReactionPicker');
    if (picker) {
        picker.querySelectorAll('.emoji-reaction-item').forEach(item => {
            item.addEventListener('click', () => {
                if (emojiPickerTarget) sendReaction(emojiPickerTarget, item.dataset.emoji);
                hideEmojiPicker();
            });
        });
    }
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#emojiReactionPicker') && !e.target.closest('.message-bubble')) {
            hideEmojiPicker();
        }
    });
});

// Добавляем двойной клик на bubble для emoji picker
function attachReactionListener(messageDiv, msg) {
    const bubble = messageDiv.querySelector('.message-bubble');
    if (!bubble) return;
    bubble.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        showEmojiPicker(msg.id, bubble);
    });
}

// ─── ПОИСК В ЧАТЕ ────────────────────────────────────────────────────────────

let searchResults = [];
let searchIndex = 0;

document.addEventListener('DOMContentLoaded', () => {
    const searchBtn = document.getElementById('searchInChatBtn');
    const searchBar = document.getElementById('chatSearchBar');
    const searchInput = document.getElementById('chatSearchInput');
    const searchClose = document.getElementById('chatSearchClose');
    const searchCount = document.getElementById('chatSearchCount');

    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            if (!currentChatUserId) return;
            searchBar.style.display = searchBar.style.display === 'none' ? 'flex' : 'none';
            if (searchBar.style.display === 'flex') searchInput.focus();
            else clearSearchHighlights();
        });
    }

    if (searchClose) {
        searchClose.addEventListener('click', () => {
            searchBar.style.display = 'none';
            clearSearchHighlights();
        });
    }

    if (searchInput) {
        let st;
        searchInput.addEventListener('input', () => {
            clearTimeout(st);
            st = setTimeout(() => runChatSearch(searchInput.value.trim(), searchCount), 300);
        });
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') navigateSearch(e.shiftKey ? -1 : 1);
        });
    }
});

async function runChatSearch(query, countEl) {
    clearSearchHighlights();
    if (!query || !currentChatUserId) { if (countEl) countEl.textContent = ''; return; }
    try {
        const r = await fetch(`/api/messages/search?user_id=${currentChatUserId}&q=${encodeURIComponent(query)}`);
        const d = await r.json();
        if (!d.success) return;
        searchResults = d.messages;
        searchIndex = 0;
        highlightSearchResults(query);
        if (countEl) countEl.textContent = searchResults.length ? `${searchResults.length} совп.` : 'Не найдено';
        if (searchResults.length) scrollToSearchResult(0);
    } catch(e) {}
}

function highlightSearchResults(query) {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    const ids = new Set(searchResults.map(m => m.id));
    container.querySelectorAll('.message').forEach(el => {
        const mid = parseInt(el.dataset.messageId);
        if (ids.has(mid)) el.classList.add('message-highlight');
    });
}

function clearSearchHighlights() {
    document.querySelectorAll('.message-highlight').forEach(el => el.classList.remove('message-highlight'));
    searchResults = [];
}

function navigateSearch(dir) {
    if (!searchResults.length) return;
    searchIndex = (searchIndex + dir + searchResults.length) % searchResults.length;
    scrollToSearchResult(searchIndex);
}

function scrollToSearchResult(idx) {
    const msg = searchResults[idx];
    if (!msg) return;
    const el = document.querySelector(`.message[data-message-id="${msg.id}"]`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// ─── ПАГИНАЦИЯ (подгрузка старых сообщений) ──────────────────────────────────

let isLoadingMore = false;
let hasMoreMessages = false;
let oldestMessageId = null;

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    container.addEventListener('scroll', () => {
        if (container.scrollTop < 80 && hasMoreMessages && !isLoadingMore) {
            loadMoreMessages();
        }
    });
});

async function loadMoreMessages() {
    if (!currentChatUserId || isLoadingMore) return;
    isLoadingMore = true;
    const container = document.getElementById('chatMessages');
    const prevHeight = container.scrollHeight;
    try {
        const r = await fetch(`/api/messages/page?user_id=${currentChatUserId}&before_id=${oldestMessageId}`);
        const d = await r.json();
        if (d.success && d.messages.length) {
            hasMoreMessages = d.has_more;
            oldestMessageId = d.messages[0].id;
            prependMessages(d.messages, container, prevHeight);
        } else {
            hasMoreMessages = false;
            const loader = document.getElementById('messagesLoadMore');
            if (loader) loader.remove();
        }
    } catch(e) {}
    isLoadingMore = false;
}

function prependMessages(messages, container, prevHeight) {
    const msgMap = {};
    messages.forEach(m => { msgMap[m.id] = m; });
    const frag = document.createDocumentFragment();
    messages.forEach(msg => {
        const isSent = Number(msg.sender_id) === Number(CURRENT_USER_ID);
        const div = document.createElement('div');
        div.className = `message ${isSent ? 'message-sent' : 'message-received'}`;
        div.dataset.messageId = msg.id;
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        if (msg.message) {
            const t = document.createElement('div');
            t.className = 'message-text-content';
            t.textContent = msg.message;
            bubble.appendChild(t);
        }
        const time = document.createElement('div');
        time.className = 'message-time';
        time.textContent = formatTime(msg.created_at);
        div.appendChild(bubble);
        div.appendChild(time);
        frag.appendChild(div);
    });
    const firstChild = container.firstChild;
    container.insertBefore(frag, firstChild);
    // Сохраняем позицию скролла
    container.scrollTop = container.scrollHeight - prevHeight;
}

// Инициализируем пагинацию при открытии чата
const _origLoadMessages = loadMessages;
loadMessages = async function(userId, scrollToBottom = false) {
    await _origLoadMessages(userId, scrollToBottom);
    if (scrollToBottom) {
        // Сбрасываем пагинацию
        const container = document.getElementById('chatMessages');
        if (container) {
            const msgs = container.querySelectorAll('.message');
            if (msgs.length) {
                oldestMessageId = parseInt(msgs[0].dataset.messageId) || null;
                hasMoreMessages = msgs.length >= 40;
            }
        }
    }
};

// ─── КОНТАКТЫ ────────────────────────────────────────────────────────────────

async function loadContacts() {    const list = document.getElementById('contactsList');
    if (!list) return;
    try {
        const r = await fetch('/api/contacts');
        const d = await r.json();
        if (!d.success) return;

        list.innerHTML = '';

        if (!d.contacts.length) {
            list.innerHTML = '<div class="contacts-empty">Нет контактов.<br>Добавьте пользователей через их профиль.</div>';
            return;
        }

        d.contacts.forEach(contact => {
            const item = document.createElement('div');
            item.className = 'contact-item user-item';
            item.dataset.userId = contact.id;

            const displayName = contact.username || contact.phone;
            const uid = contact.user_id || '';
            const initials = contact.phone ? contact.phone.slice(-2) : uid.slice(0, 2).toUpperCase();

            let avatarHtml = '';
            if (contact.avatar_path) {
                avatarHtml = `<div class="user-avatar" style="padding:0;overflow:hidden;"><img src="/uploads/${contact.avatar_path}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" alt=""></div>`;
            } else {
                avatarHtml = `<div class="user-avatar"><span>${initials}</span></div>`;
            }

            item.innerHTML = `
                ${avatarHtml}
                <div class="user-details">
                    <span class="user-name">${displayName}</span>
                    <span class="chat-preview" style="opacity:0.5;">@${uid}</span>
                </div>
                ${contact.online ? '<span class="contact-online-dot"></span>' : ''}
            `;

            item.addEventListener('click', () => openChat(contact.id, contact.phone, contact.username));
            list.appendChild(item);
        });
    } catch(e) {
        console.error('Ошибка загрузки контактов:', e);
    }
}

// ─── ГРУППЫ ──────────────────────────────────────────────────────────────────

let currentGroupId = null;
let groupMessagesInterval = null;

async function loadGroups() {
    const chatsList = document.getElementById('chatsList');
    if (!chatsList) return;
    try {
        const r = await fetch('/api/groups');
        const d = await r.json();
        if (!d.success) return;
        // Добавляем группы в конец списка чатов
        d.groups.forEach(group => {
            if (chatsList.querySelector(`[data-group-id="${group.id}"]`)) return;
            const item = document.createElement('div');
            item.className = 'user-item group-item';
            item.dataset.groupId = group.id;
            const preview = group.last_message ? group.last_message.slice(0, 40) : 'Нет сообщений';
            item.innerHTML = `
                <div class="user-avatar group-avatar"><span>#</span></div>
                <div class="user-details">
                    <span class="user-name">${group.name}</span>
                    <span class="chat-preview" style="opacity:0.5;">${preview}</span>
                </div>
            `;
            item.addEventListener('click', () => openGroupChat(group.id, group.name));
            chatsList.appendChild(item);
        });
    } catch(e) { console.error('Ошибка загрузки групп:', e); }
}

async function openGroupChat(groupId, groupName) {
    currentGroupId = groupId;
    currentChatUserId = null;

    const placeholder = document.getElementById('chatPlaceholder');
    const chatWindow = document.getElementById('chatWindow');
    const chatUserName = document.getElementById('chatUserName');
    const chatUserAvatarText = document.getElementById('chatUserAvatarText');
    const chatUserStatus = document.getElementById('chatUserStatus');

    if (placeholder) placeholder.style.display = 'none';
    if (chatWindow) chatWindow.style.display = 'flex';
    if (chatUserName) chatUserName.textContent = groupName;
    if (chatUserAvatarText) chatUserAvatarText.textContent = '#';
    if (chatUserStatus) chatUserStatus.textContent = 'группа';

    document.querySelectorAll('.user-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.groupId == groupId) item.classList.add('active');
    });

    if (window.innerWidth <= 768) {
        document.getElementById('usersSidebar').classList.add('hidden');
        document.getElementById('chatArea').classList.add('fullscreen');
    }

    await loadGroupMessages(groupId, true);

    if (messagesInterval) clearInterval(messagesInterval);
    if (groupMessagesInterval) clearInterval(groupMessagesInterval);
    groupMessagesInterval = setInterval(() => loadGroupMessages(groupId), 2000);
}

async function loadGroupMessages(groupId, scrollToBottom = false) {
    try {
        const r = await fetch(`/api/groups/${groupId}/messages`);
        const d = await r.json();
        if (d.success) displayGroupMessages(d.messages, scrollToBottom);
    } catch(e) { console.error('Ошибка загрузки сообщений группы:', e); }
}

function displayGroupMessages(messages, scrollToBottom = true) {
    const container = document.getElementById('chatMessages');
    if (!container) return;
    const wasAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 100;
    container.innerHTML = '';

    if (!messages.length) {
        container.innerHTML = '<div class="empty-chat">Нет сообщений. Начните переписку!</div>';
        return;
    }

    messages.forEach(msg => {
        const isSent = Number(msg.sender_id) === Number(CURRENT_USER_ID);
        const div = document.createElement('div');
        div.className = `message ${isSent ? 'message-sent' : 'message-received'}`;
        div.dataset.messageId = msg.id;

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';

        if (!isSent) {
            const senderName = document.createElement('div');
            senderName.className = 'group-message-sender';
            senderName.textContent = msg.username || msg.phone;
            bubble.appendChild(senderName);
        }

        if (msg.image_path) {
            const img = document.createElement('img');
            img.src = `/uploads/${msg.image_path}`;
            img.className = 'message-image';
            img.loading = 'lazy';
            bubble.appendChild(img);
        }

        if (msg.message) {
            const t = document.createElement('div');
            t.className = 'message-text-content';
            t.textContent = msg.message;
            bubble.appendChild(t);
        }

        const time = document.createElement('div');
        time.className = 'message-time';
        time.textContent = formatTime(msg.created_at);

        div.appendChild(bubble);
        div.appendChild(time);
        container.appendChild(div);
    });

    if (scrollToBottom || wasAtBottom) {
        requestAnimationFrame(() => { container.scrollTop = container.scrollHeight; });
    }
}

// Перехватываем отправку формы для групп — capture phase, до основного обработчика
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('messageForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            if (!currentGroupId) return; // обычный чат обработает сам
            e.preventDefault();
            e.stopImmediatePropagation();
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            if (!message) return;
            try {
                const fd = new FormData();
                fd.append('message', message);
                const r = await fetch(`/api/groups/${currentGroupId}/messages`, { method: 'POST', body: fd });
                const d = await r.json();
                if (d.success) {
                    input.value = '';
                    updateInputButtons();
                    await loadGroupMessages(currentGroupId, true);
                }
            } catch(err) { console.error(err); }
        }, true); // capture phase
    }
});

// ─── МОДАЛ СОЗДАНИЯ ГРУППЫ ───────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
    const createGroupMenuItem = document.getElementById('createGroupMenuItem');
    const createGroupModal = document.getElementById('createGroupModal');
    const createGroupBackdrop = document.getElementById('createGroupBackdrop');
    const createGroupClose = document.getElementById('createGroupClose');
    const createGroupSubmit = document.getElementById('createGroupSubmit');

    function openCreateGroupModal() {
        const menuDropdown = document.getElementById('menuDropdown');
        if (menuDropdown) menuDropdown.classList.remove('show');
        if (createGroupModal) createGroupModal.classList.add('show');
        loadContactsForGroup();
    }

    function closeCreateGroupModal() {
        if (createGroupModal) createGroupModal.classList.remove('show');
    }

    if (createGroupMenuItem) createGroupMenuItem.addEventListener('click', openCreateGroupModal);
    if (createGroupBackdrop) createGroupBackdrop.addEventListener('click', closeCreateGroupModal);
    if (createGroupClose) createGroupClose.addEventListener('click', closeCreateGroupModal);

    if (createGroupSubmit) {
        createGroupSubmit.addEventListener('click', async () => {
            const name = (document.getElementById('groupNameInput').value || '').trim();
            if (!name) { showToast('Введите название группы'); return; }

            const checked = document.querySelectorAll('#groupMembersList .group-member-check:checked');
            const memberIds = Array.from(checked).map(cb => parseInt(cb.value));
            if (!memberIds.length) { showToast('Выберите хотя бы одного участника'); return; }

            createGroupSubmit.disabled = true;
            try {
                const r = await fetch('/api/groups', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, member_ids: memberIds })
                });
                const d = await r.json();
                if (d.success) {
                    showToast('Группа создана');
                    closeCreateGroupModal();
                    document.getElementById('groupNameInput').value = '';
                    await loadGroups();
                    openGroupChat(d.group_id, name);
                } else {
                    showToast('Ошибка: ' + (d.message || ''));
                }
            } catch(e) {
                showToast('Ошибка соединения');
            } finally {
                createGroupSubmit.disabled = false;
            }
        });
    }
});

async function loadContactsForGroup() {
    const list = document.getElementById('groupMembersList');
    if (!list) return;
    list.innerHTML = '<div class="empty-users">Загрузка...</div>';
    try {
        const r = await fetch('/api/contacts');
        const d = await r.json();
        if (!d.success || !d.contacts.length) {
            list.innerHTML = '<div class="empty-users">Нет контактов. Сначала добавьте пользователей в контакты.</div>';
            return;
        }
        list.innerHTML = '';
        d.contacts.forEach(contact => {
            const label = document.createElement('label');
            label.className = 'group-member-label';
            const displayName = contact.username || contact.phone;
            const uid = contact.user_id ? `@${contact.user_id}` : contact.phone;
            label.innerHTML = `
                <input type="checkbox" class="group-member-check" value="${contact.id}">
                <div class="user-avatar" style="width:36px;height:36px;font-size:13px;flex-shrink:0;">
                    <span>${contact.phone ? contact.phone.slice(-2) : '??'}</span>
                </div>
                <div class="user-details">
                    <span class="user-name" style="font-size:14px;">${displayName}</span>
                    <span class="chat-preview">${uid}</span>
                </div>
                ${contact.online ? '<span class="contact-online-dot"></span>' : ''}
            `;
            list.appendChild(label);
        });
    } catch(e) {
        list.innerHTML = '<div class="empty-users">Ошибка загрузки</div>';
    }
}
