// Контекстное меню для сообщений
let contextMenu = null;
let currentMessage = null;
let longPressTimer = null;
let isLongPress = false;

// Инициализация контекстного меню
function initContextMenu() {
    contextMenu = document.getElementById('messageContextMenu');
    if (!contextMenu) return;
    
    // Закрытие меню при клике вне его
    document.addEventListener('click', (e) => {
        if (contextMenu && contextMenu.classList.contains('show')) {
            if (!contextMenu.contains(e.target) && !e.target.closest('.message-bubble')) {
                closeContextMenu();
            }
        }
    });
    
    // Закрытие меню при нажатии Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && contextMenu && contextMenu.classList.contains('show')) {
            closeContextMenu();
        }
    });
    
    // Обработчики для пунктов меню
    setupContextMenuHandlers();
}

// Настройка обработчиков пунктов меню
function setupContextMenuHandlers() {
    const actions = {
        reply: handleReply,
        edit: handleEdit,
        copy: handleCopy,
        forward: handleForward,
        deleteForMe: handleDeleteForMe,
        deleteForEveryone: handleDeleteForEveryone
    };

    Object.keys(actions).forEach(action => {
        const id = 'contextMenu' + action.charAt(0).toUpperCase() + action.slice(1);
        const button = document.getElementById(id);
        if (button) {
            button.addEventListener('click', () => {
                if (currentMessage) {
                    actions[action](currentMessage);
                    closeContextMenu();
                }
            });
        }
    });
}

// Показать контекстное меню
function showContextMenu(message, x, y, messageElement) {
    if (!contextMenu || !message) return;
    
    currentMessage = message;

    updateContextMenuItems(message);
    
    // Позиционируем меню
    positionContextMenu(x, y);
    
    contextMenu.classList.add('show');
    
    // Сохраняем ссылку на элемент сообщения для выделения
    if (messageElement) {
        messageElement.classList.add('message-context-active');
    }
}

// Обновление видимости пунктов меню
function updateContextMenuItems(message) {
    const isSent = Number(message.sender_id) === Number(CURRENT_USER_ID);

    const editBtn = document.getElementById('contextMenuEdit');
    const deleteForMeBtn = document.getElementById('contextMenuDeleteForMe');
    const deleteForEveryoneBtn = document.getElementById('contextMenuDeleteForEveryone');

    if (editBtn) {
        editBtn.style.display = isSent ? 'flex' : 'none';
    }
    if (deleteForMeBtn) {
        deleteForMeBtn.style.display = 'flex';
    }
    if (deleteForEveryoneBtn) {
        deleteForEveryoneBtn.style.display = isSent ? 'flex' : 'none';
    }

    const copyBtn = document.getElementById('contextMenuCopy');
    if (copyBtn) {
        copyBtn.style.display = message.message ? 'flex' : 'none';
    }
}

// Позиционирование меню
function positionContextMenu(x, y) {
    if (!contextMenu) return;
    
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // На мобильных - снизу по центру
        contextMenu.style.left = '0';
        contextMenu.style.right = '0';
        contextMenu.style.top = 'auto';
        contextMenu.style.bottom = '0';
        contextMenu.style.transform = 'none';
    } else {
        // На десктопе - рядом с курсором
        const menuWidth = contextMenu.offsetWidth || 240;
        const menuHeight = contextMenu.offsetHeight || 400;
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        let left = x;
        let top = y;
        
        // Проверяем, не выходит ли за правый край
        if (left + menuWidth > windowWidth) {
            left = windowWidth - menuWidth - 10;
        }
        
        // Проверяем, не выходит ли за нижний край
        if (top + menuHeight > windowHeight) {
            top = windowHeight - menuHeight - 10;
        }
        
        // Минимальные отступы от краев
        left = Math.max(10, left);
        top = Math.max(10, top);
        
        contextMenu.style.left = left + 'px';
        contextMenu.style.top = top + 'px';
        contextMenu.style.right = 'auto';
        contextMenu.style.bottom = 'auto';
        contextMenu.style.transform = 'none';
    }
}

// Закрытие контекстного меню
function closeContextMenu() {
    if (contextMenu) {
        contextMenu.classList.remove('show');
    }
    
    // Убираем выделение с сообщения
    document.querySelectorAll('.message-context-active').forEach(el => {
        el.classList.remove('message-context-active');
    });
    
    currentMessage = null;
    isLongPress = false;
}

// Обработка правого клика мыши (глобальная функция)
window.handleContextMenu = function(e, message, messageElement) {
    e.preventDefault();
    e.stopPropagation();
    
    showContextMenu(message, e.clientX, e.clientY, messageElement);
};

// Обработка долгого нажатия на мобильных (глобальная функция)
window.handleLongPressStart = function(e, message, messageElement) {
    isLongPress = false;
    if (longPressTimer) {
        clearTimeout(longPressTimer);
    }
    
    longPressTimer = setTimeout(() => {
        isLongPress = true;
        // Вибрация (если поддерживается)
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }
        
        const touch = e.touches && e.touches[0] ? e.touches[0] : (e.changedTouches && e.changedTouches[0] ? e.changedTouches[0] : { clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 });
        showContextMenu(message, touch.clientX, touch.clientY, messageElement);
    }, 500); // 500ms для долгого нажатия
};

window.handleLongPressEnd = function(e) {
    if (longPressTimer) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
    }
    
    // Если это было долгое нажатие, предотвращаем обычный клик
    if (isLongPress) {
        e.preventDefault();
        e.stopPropagation();
    }
};

// Переменные для управления функциями (глобальные)
window.replyToMessage = null;
window.selectedMessages = new Set();
window.editingMessageId = null;

// Обработчики действий меню
async function handleReply(message) {
    window.replyToMessage = message;
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        messageInput.focus();
        messageInput.placeholder = `Ответить на: ${message.message ? (message.message.length > 30 ? message.message.substring(0, 30) + '...' : message.message) : '📷 Фото'}`;
        if (typeof showToast === 'function') {
            showToast('Введите ответ на сообщение');
        }
    }
}

async function handleEdit(message) {
    window.editingMessageId = message.id;
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        messageInput.value = message.message || '';
        messageInput.focus();
        messageInput.placeholder = 'Редактировать сообщение...';
        if (typeof updateInputButtons === 'function') {
            updateInputButtons();
        }
        if (typeof showToast === 'function') {
            showToast('Редактируйте сообщение и нажмите Enter для сохранения');
        }
    }
}

function handleCopy(message) {
    const text = message && (message.message != null ? String(message.message).trim() : '');
    if (text) {
        const done = () => {
            if (typeof showToast === 'function') showToast('Текст скопирован');
        };
        const fallback = () => {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly', '');
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            ta.style.top = '0';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            ta.setSelectionRange(0, text.length);
            try {
                if (document.execCommand('copy')) {
                    done();
                } else {
                    if (typeof showToast === 'function') showToast('Не удалось скопировать');
                }
            } catch (e) {
                if (typeof showToast === 'function') showToast('Не удалось скопировать');
            }
            document.body.removeChild(ta);
        };
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(text).then(done).catch(fallback);
        } else {
            fallback();
        }
    } else if (message && message.image_path) {
        if (typeof showToast === 'function') showToast('Изображение нельзя скопировать');
    } else {
        if (typeof showToast === 'function') showToast('Нет текста для копирования');
    }
}

async function handleForward(message) {
    // Для упрощения пересылаем в текущий чат (можно улучшить позже)
    if (typeof currentChatUserId === 'undefined' || !currentChatUserId) {
        if (typeof showToast === 'function') {
            showToast('Выберите чат для пересылки');
        }
        return;
    }
    
    try {
        const response = await fetch(`/api/messages/${message.id}/forward`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                receiver_id: currentChatUserId
            })
        });
        
        const data = await response.json();
        if (data.success) {
            if (typeof showToast === 'function') {
                showToast('Сообщение переслано');
            }
            // Перезагружаем сообщения
            if (typeof loadMessages === 'function') {
                await loadMessages(currentChatUserId, true);
            }
        } else {
            if (typeof showToast === 'function') {
                showToast('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
            }
        }
    } catch (error) {
        console.error('Ошибка пересылки сообщения:', error);
        if (typeof showToast === 'function') {
            showToast('Ошибка соединения с сервером');
        }
    }
}

async function handleDeleteForMe(message) {
    try {
        const response = await fetch(`/api/messages/${message.id}?scope=me`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();
        if (data.success) {
            if (typeof showToast === 'function') showToast('Сообщение удалено у вас');
            if (typeof currentChatUserId !== 'undefined' && currentChatUserId && typeof loadMessages === 'function') {
                await loadMessages(currentChatUserId, false);
            }
        } else {
            if (typeof showToast === 'function') showToast('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
        }
    } catch (error) {
        console.error('Ошибка удаления сообщения:', error);
        if (typeof showToast === 'function') showToast('Ошибка соединения с сервером');
    }
}

async function handleDeleteForEveryone(message) {
    try {
        const response = await fetch(`/api/messages/${message.id}?scope=everyone`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();
        if (data.success) {
            if (typeof showToast === 'function') showToast('Сообщение удалено у всех');
            if (typeof currentChatUserId !== 'undefined' && currentChatUserId && typeof loadMessages === 'function') {
                await loadMessages(currentChatUserId, false);
            }
            if (typeof silentLoadChats === 'function') await silentLoadChats();
        } else {
            if (typeof showToast === 'function') showToast('Ошибка: ' + (data.message || 'Неизвестная ошибка'));
        }
    } catch (error) {
        console.error('Ошибка удаления сообщения:', error);
        if (typeof showToast === 'function') showToast('Ошибка соединения с сервером');
    }
}


// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    initContextMenu();
});
