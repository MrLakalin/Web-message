// Переменные для управления чатом
let currentChatUserId = null;
let messagesInterval = null;
let searchTimeout = null;

// Загрузка списка чатов (без показа загрузки)
async function loadChats() {
    const chatsList = document.getElementById('chatsList');
    if (!chatsList) return;

    // Сохраняем текущее состояние перед обновлением
    const activeUserId = currentChatUserId;
    const wasScrolled = chatsList.scrollTop;
    const hadContent = chatsList.querySelector('.user-item') || chatsList.querySelector('.empty-users');

    try {
        const response = await fetch('/api/chats');
        const data = await response.json();

        if (data.success) {
            if (data.chats.length === 0) {
                // Показываем пустое сообщение только если список действительно пуст
                if (!hadContent) {
                    chatsList.innerHTML = '<div class="empty-users">Нет чатов. Найдите пользователя для начала переписки.</div>';
                }
                return;
            }

            // Быстро очищаем и обновляем без показа загрузки
            chatsList.innerHTML = '';

            data.chats.forEach(chat => {
                const chatItem = document.createElement('div');
                chatItem.className = 'user-item chat-item';
                chatItem.dataset.userId = chat.id;
                
                // Восстанавливаем активное состояние
                if (Number(chat.id) === Number(activeUserId)) {
                    chatItem.classList.add('active');
                }
                
                chatItem.innerHTML = `
                    <div class="user-avatar">
                        <span>${chat.phone.charAt(chat.phone.length - 2)}${chat.phone.charAt(chat.phone.length - 1)}</span>
                    </div>
                    <div class="user-details">
                        <span class="user-name">${chat.phone}</span>
                        ${chat.last_message ? `<span class="chat-preview">${chat.last_message.substring(0, 40)}${chat.last_message.length > 40 ? '...' : ''}</span>` : ''}
                    </div>
                `;
                // Добавляем обработчики для клика и тача
                const handleChatOpen = (e) => {
                    e.stopPropagation();
                    openChat(chat.id, chat.phone);
                };
                chatItem.addEventListener('click', handleChatOpen);
                chatItem.addEventListener('touchend', handleChatOpen, { passive: true });
                chatsList.appendChild(chatItem);
            });
            
            // Восстанавливаем позицию прокрутки только если был контент
            if (hadContent) {
                chatsList.scrollTop = wasScrolled;
            }
        }
    } catch (error) {
        console.error('Ошибка загрузки чатов:', error);
        // Не показываем ошибку при автоматических обновлениях
    }
}

// Тихая загрузка чатов (алиас для единообразия)
async function silentLoadChats() {
    await loadChats();
}

// Поиск пользователей по номеру
async function searchUsers(searchQuery) {
    const usersList = document.getElementById('usersList');
    const chatsList = document.getElementById('chatsList');
    
    // Убираем все нецифровые символы
    const cleanQuery = searchQuery.replace(/\D/g, '');
    
    if (cleanQuery.length < 3) {
        usersList.style.display = 'none';
        chatsList.style.display = 'flex';
        loadChats();
        return;
    }

    // Показываем результаты поиска, скрываем список чатов
    chatsList.style.display = 'none';
    usersList.style.display = 'flex';
    // Не показываем индикатор загрузки при поиске

    try {
        const response = await fetch(`/api/users/search?q=${encodeURIComponent(cleanQuery)}`);
        const data = await response.json();

        if (data.success) {
            if (data.users.length === 0) {
                usersList.innerHTML = '<div class="empty-users">Пользователи не найдены</div>';
                return;
            }

            usersList.innerHTML = '';
            data.users.forEach(user => {
                const userItem = document.createElement('div');
                userItem.className = 'user-item';
                userItem.dataset.userId = user.id;
                userItem.innerHTML = `
                    <div class="user-avatar">
                        <span>${user.phone.charAt(user.phone.length - 2)}${user.phone.charAt(user.phone.length - 1)}</span>
                    </div>
                    <div class="user-details">
                        <span class="user-name">${user.phone}</span>
                    </div>
                `;
                // Добавляем обработчики для клика и тача
                const handleUserOpen = (e) => {
                    e.stopPropagation();
                    openChat(user.id, user.phone);
                };
                userItem.addEventListener('click', handleUserOpen);
                userItem.addEventListener('touchend', handleUserOpen, { passive: true });
                usersList.appendChild(userItem);
            });
        } else {
            usersList.innerHTML = '<div class="error-users">Ошибка поиска</div>';
        }
    } catch (error) {
        console.error('Ошибка поиска пользователей:', error);
        usersList.innerHTML = '<div class="error-users">Ошибка соединения</div>';
    }
}

// Открытие чата с пользователем
async function openChat(userId, userPhone) {
    if (!userId || !userPhone) {
        console.error('openChat: неверные параметры', userId, userPhone);
        return;
    }
    
    currentChatUserId = userId;
    
    // Обновление UI
    const placeholder = document.getElementById('chatPlaceholder');
    const chatWindow = document.getElementById('chatWindow');
    const chatUserName = document.getElementById('chatUserName');
    
    if (placeholder) placeholder.style.display = 'none';
    if (chatWindow) chatWindow.style.display = 'flex';
    if (chatUserName) chatUserName.textContent = userPhone;

    // Выделение активного пользователя в списке чатов и результатов поиска
    document.querySelectorAll('.user-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.userId == userId) {
            item.classList.add('active');
        }
    });

    // На мобильных устройствах скрываем список и показываем чат
    if (window.innerWidth <= 768) {
        document.getElementById('usersSidebar').classList.add('hidden');
        document.getElementById('chatArea').classList.add('fullscreen');
    }

    // Загрузка сообщений (прокрутка вниз при открытии)
    await loadMessages(userId, true);

    // Автообновление сообщений каждую секунду
    if (messagesInterval) {
        clearInterval(messagesInterval);
    }
    messagesInterval = setInterval(() => loadMessages(userId), 1000);

    // Фокус на поле ввода
    document.getElementById('messageInput').focus();
}

// Загрузка сообщений
async function loadMessages(userId, scrollToBottom = false) {
    try {
        const response = await fetch(`/api/messages?user_id=${userId}`);
        const data = await response.json();

        if (data.success) {
            displayMessages(data.messages, scrollToBottom);
        }
    } catch (error) {
        console.error('Ошибка загрузки сообщений:', error);
    }
}

// Отображение сообщений
function displayMessages(messages, scrollToBottom = true) {
    const messagesContainer = document.getElementById('chatMessages');
    if (!messagesContainer) return;

    // Сохраняем текущую позицию прокрутки и высоту
    const wasAtBottom = messagesContainer.scrollHeight - messagesContainer.scrollTop <= messagesContainer.clientHeight + 100;
    const oldScrollHeight = messagesContainer.scrollHeight;
    
    messagesContainer.innerHTML = '';

    if (messages.length === 0) {
        messagesContainer.innerHTML = '<div class="empty-chat">Пока нет сообщений. Начните переписку!</div>';
        return;
    }

    messages.forEach(msg => {
        const messageDiv = document.createElement('div');
        // Приводим к числам для корректного сравнения
        const isSent = Number(msg.sender_id) === Number(CURRENT_USER_ID);
        messageDiv.className = `message ${isSent ? 'message-sent' : 'message-received'}`;
        
        const messageText = document.createElement('div');
        messageText.className = 'message-text';
        messageText.textContent = msg.message;

        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.textContent = formatTime(msg.created_at);

        messageDiv.appendChild(messageText);
        messageDiv.appendChild(messageTime);
        messagesContainer.appendChild(messageDiv);
    });

    // Прокрутка вниз только если нужно или пользователь был внизу
    if (scrollToBottom || wasAtBottom) {
        // Используем requestAnimationFrame для плавной прокрутки
        requestAnimationFrame(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        });
    } else {
        // Сохраняем позицию прокрутки при обновлении
        const newScrollHeight = messagesContainer.scrollHeight;
        const scrollDiff = newScrollHeight - oldScrollHeight;
        messagesContainer.scrollTop += scrollDiff;
    }
}

// Форматирование времени
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) { // Меньше минуты
        return 'только что';
    } else if (diff < 3600000) { // Меньше часа
        const minutes = Math.floor(diff / 60000);
        return `${minutes} мин назад`;
    } else if (diff < 86400000) { // Меньше суток
        return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    } else {
        return date.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) + ' ' + 
               date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    }
}

// Отправка сообщения
const messageForm = document.getElementById('messageForm');
if (messageForm) {
    messageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!currentChatUserId) return;

        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();

        if (!message) return;

        try {
            const response = await fetch('/api/messages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    receiver_id: currentChatUserId,
                    message: message
                })
            });

            const data = await response.json();
            
            if (data.success) {
                messageInput.value = '';
                // Перезагружаем сообщения (прокрутка вниз после отправки)
                await loadMessages(currentChatUserId, true);
                // Тихая обновление списка чатов
                await silentLoadChats();
            } else {
                alert('Ошибка отправки сообщения: ' + (data.message || 'Неизвестная ошибка'));
            }
        } catch (error) {
            console.error('Ошибка отправки сообщения:', error);
            alert('Ошибка соединения с сервером');
        }
    });
}

// Кнопка "Назад" для мобильных устройств
const backBtn = document.getElementById('backBtn');
if (backBtn) {
    backBtn.addEventListener('click', () => {
        // На мобильных устройствах показываем список и скрываем чат
        if (window.innerWidth <= 768) {
            document.getElementById('usersSidebar').classList.remove('hidden');
            document.getElementById('chatArea').classList.remove('fullscreen');
            document.getElementById('chatPlaceholder').style.display = 'flex';
            document.getElementById('chatWindow').style.display = 'none';
        }

        // Останавливаем автообновление
        if (messagesInterval) {
            clearInterval(messagesInterval);
            messagesInterval = null;
        }

        currentChatUserId = null;

        // Снимаем выделение активного пользователя
        document.querySelectorAll('.user-item').forEach(item => {
            item.classList.remove('active');
        });
    });
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Загружаем список чатов (тихо, без индикаторов)
    loadChats();
    
    // Обработка меню
    const menuBtn = document.getElementById('menuBtn');
    const menuDropdown = document.getElementById('menuDropdown');
    const logoutMenuItem = document.getElementById('logoutMenuItem');
    
    if (menuBtn && menuDropdown) {
        // Показать/скрыть меню при клике на кнопку
        menuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            menuDropdown.classList.toggle('show');
        });
        
        // Закрыть меню при клике вне его
        document.addEventListener('click', (e) => {
            if (!menuBtn.contains(e.target) && !menuDropdown.contains(e.target)) {
                menuDropdown.classList.remove('show');
            }
        });
    }
    
    // Обработка выхода из аккаунта
    if (logoutMenuItem) {
        logoutMenuItem.addEventListener('click', async () => {
            try {
                const response = await fetch('/api/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                
                const data = await response.json();
                if (data.success) {
                    window.location.href = data.redirect || '/login';
                }
            } catch (error) {
                console.error('Ошибка выхода:', error);
            }
        });
    }
    
    const searchInput = document.getElementById('searchInput');
    
    if (searchInput) {
        // Поиск с задержкой (debounce)
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            if (searchTimeout) {
                clearTimeout(searchTimeout);
            }
            
            if (query.length === 0) {
                // Если поиск пустой, показываем список чатов
                document.getElementById('usersList').style.display = 'none';
                document.getElementById('chatsList').style.display = 'flex';
                loadChats();
                return;
            }
            
            searchTimeout = setTimeout(() => {
                searchUsers(query);
            }, 300); // Задержка 300мс перед поиском
        });
    }
    
    // Автообновление списка чатов каждую секунду (тихо, без визуальных индикаторов)
    setInterval(() => {
        const searchInput = document.getElementById('searchInput');
        if (!currentChatUserId && (!searchInput || searchInput.value.trim() === '')) {
            // Показываем список чатов, если он скрыт
            const chatsList = document.getElementById('chatsList');
            const usersList = document.getElementById('usersList');
            if (chatsList && usersList && usersList.style.display !== 'flex') {
                chatsList.style.display = 'flex';
                usersList.style.display = 'none';
                silentLoadChats();
            } else if (chatsList && chatsList.style.display === 'flex') {
                silentLoadChats();
            }
        }
    }, 1000);
});

// Обработка изменения размера окна
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        // На десктопе всегда показываем обе колонки
        document.getElementById('usersSidebar').classList.remove('hidden');
        document.getElementById('chatArea').classList.remove('fullscreen');
    }
});

// Предотвращение скролла всего контейнера при открытии клавиатуры на мобильных
if (window.innerWidth <= 768) {
    // Предотвращаем скролл body и html
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
    
    const messageInput = document.getElementById('messageInput');
    if (messageInput) {
        let lastScrollTop = 0;
        
        messageInput.addEventListener('focus', (e) => {
            // Сохраняем текущую позицию скролла
            lastScrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Предотвращаем скролл body
            window.scrollTo(0, lastScrollTop);
            
            // Прокручиваем сообщения вниз после небольшой задержки (когда клавиатура откроется)
            setTimeout(() => {
                const messagesContainer = document.getElementById('chatMessages');
                if (messagesContainer) {
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }
                // Убеждаемся, что body не скроллится
                window.scrollTo(0, lastScrollTop);
            }, 100);
            
            setTimeout(() => {
                window.scrollTo(0, lastScrollTop);
            }, 300);
        }, { passive: false });

        // Предотвращаем скролл при вводе
        messageInput.addEventListener('touchstart', (e) => {
            e.stopPropagation();
        }, { passive: true });
        
        // Предотвращаем скролл при изменении размера viewport (открытие клавиатуры)
        window.addEventListener('resize', () => {
            if (document.activeElement === messageInput) {
                window.scrollTo(0, lastScrollTop);
            }
        });
    }

    // Предотвращаем скролл при касании области сообщений
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) {
        chatMessages.addEventListener('touchmove', (e) => {
            // Разрешаем скролл только внутри chat-messages
            e.stopPropagation();
        }, { passive: true });
    }

    // Предотвращаем скролл всего контейнера, но разрешаем клики
    const messengerContainer = document.querySelector('.messenger-container');
    if (messengerContainer) {
        messengerContainer.addEventListener('touchmove', (e) => {
            // Если скролл происходит не в chat-messages и не в списках чатов, предотвращаем его
            if (!e.target.closest('.chat-messages') && 
                !e.target.closest('.chat-input-container') && 
                !e.target.closest('.chats-list') && 
                !e.target.closest('.users-list')) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // НЕ блокируем touchstart, чтобы клики работали
    }
}
