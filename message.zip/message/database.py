import sqlite3
import bcrypt
import os

DB_NAME = 'messenger.db'

def get_db_connection():
    """Создание подключения к базе данных"""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Инициализация базы данных - создание таблиц пользователей и сообщений"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print(f"База данных {DB_NAME} инициализирована")

def hash_password(password):
    """Хеширование пароля с использованием bcrypt"""
    salt = bcrypt.gensalt()
    password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
    return password_hash.decode('utf-8')

def verify_password(password, password_hash):
    """Проверка пароля"""
    return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))

def register_user(phone, password):
    """Регистрация нового пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Проверка существования пользователя
        cursor.execute('SELECT id FROM users WHERE phone = ?', (phone,))
        if cursor.fetchone():
            conn.close()
            return None
        
        # Хеширование пароля
        password_hash = hash_password(password)
        
        # Вставка нового пользователя
        cursor.execute(
            'INSERT INTO users (phone, password_hash) VALUES (?, ?)',
            (phone, password_hash)
        )
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return user_id
        
    except sqlite3.IntegrityError:
        conn.close()
        return None
    except Exception as e:
        conn.close()
        raise e

def authenticate_user(phone, password):
    """Аутентификация пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, phone, password_hash FROM users WHERE phone = ?', (phone,))
    user = cursor.fetchone()
    conn.close()
    
    if user and verify_password(password, user['password_hash']):
        return {
            'id': user['id'],
            'phone': user['phone']
        }
    
    return None

def get_all_users(exclude_user_id):
    """Получение списка всех пользователей кроме текущего"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, phone FROM users WHERE id != ? ORDER BY phone', (exclude_user_id,))
    users = cursor.fetchall()
    conn.close()
    
    return [{'id': user['id'], 'phone': user['phone']} for user in users]

def search_users_by_phone(exclude_user_id, search_query):
    """Поиск пользователей по номеру телефона"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Поиск по частичному совпадению номера
    search_pattern = f'%{search_query}%'
    cursor.execute(
        'SELECT id, phone FROM users WHERE id != ? AND phone LIKE ? ORDER BY phone LIMIT 20',
        (exclude_user_id, search_pattern)
    )
    users = cursor.fetchall()
    conn.close()
    
    return [{'id': user['id'], 'phone': user['phone']} for user in users]

def send_message(sender_id, receiver_id, message):
    """Отправка сообщения"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute(
        'INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)',
        (sender_id, receiver_id, message)
    )
    
    message_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return message_id

def get_messages(user_id, other_user_id):
    """Получение сообщений между двумя пользователями"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, sender_id, receiver_id, message, created_at
        FROM messages
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ORDER BY created_at ASC
    ''', (user_id, other_user_id, other_user_id, user_id))
    
    messages = cursor.fetchall()
    conn.close()
    
    return [{
        'id': msg['id'],
        'sender_id': msg['sender_id'],
        'receiver_id': msg['receiver_id'],
        'message': msg['message'],
        'created_at': msg['created_at']
    } for msg in messages]

def get_user_by_id(user_id):
    """Получение пользователя по ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, phone FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return {'id': user['id'], 'phone': user['phone']}
    return None

def get_user_chats(user_id):
    """Получение списка пользователей, с которыми есть переписка"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Получаем уникальных пользователей, с которыми есть сообщения
    cursor.execute('''
        SELECT DISTINCT
            CASE 
                WHEN sender_id = ? THEN receiver_id
                ELSE sender_id
            END as other_user_id
        FROM messages
        WHERE sender_id = ? OR receiver_id = ?
    ''', (user_id, user_id, user_id))
    
    user_ids = cursor.fetchall()
    
    result = []
    for row in user_ids:
        other_user_id = row['other_user_id']
        if not other_user_id:
            continue
            
        # Получаем информацию о пользователе
        cursor.execute('SELECT id, phone FROM users WHERE id = ?', (other_user_id,))
        user = cursor.fetchone()
        
        if user:
            # Получаем последнее сообщение с этим пользователем
            cursor.execute('''
                SELECT message, created_at 
                FROM messages
                WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
                ORDER BY created_at DESC
                LIMIT 1
            ''', (user_id, other_user_id, other_user_id, user_id))
            
            last_msg = cursor.fetchone()
            
            result.append({
                'id': user['id'],
                'phone': user['phone'],
                'last_message': last_msg['message'] if last_msg else None,
                'last_message_time': last_msg['created_at'] if last_msg else None
            })
    
    # Сортируем по времени последнего сообщения
    result.sort(key=lambda x: x['last_message_time'] or '', reverse=True)
    
    conn.close()
    return result
