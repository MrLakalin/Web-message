from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from database import init_db, register_user, authenticate_user, get_all_users, send_message, get_messages, get_user_by_id, search_users_by_phone, get_user_chats
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Секретный ключ для сессий

# Инициализация базы данных при запуске
init_db()

@app.route('/')
def index():
    """Главная страница - редирект на авторизацию"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    """Страница авторизации"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/register')
def register():
    """Страница регистрации"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/api/register', methods=['POST'])
def api_register():
    """API endpoint для регистрации"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        password = data.get('password', '').strip()
        
        # Валидация
        if not phone or not password:
            return jsonify({'success': False, 'message': 'Номер телефона и пароль обязательны'}), 400
        
        # Простая валидация номера телефона (только цифры, минимум 10 символов)
        if not phone.isdigit() or len(phone) < 10:
            return jsonify({'success': False, 'message': 'Некорректный номер телефона'}), 400
        
        if len(password) < 6:
            return jsonify({'success': False, 'message': 'Пароль должен содержать минимум 6 символов'}), 400
        
        # Регистрация пользователя
        user_id = register_user(phone, password)
        
        if user_id:
            session['user_id'] = user_id
            session['phone'] = phone
            return jsonify({'success': True, 'message': 'Регистрация успешна', 'redirect': '/dashboard'})
        else:
            return jsonify({'success': False, 'message': 'Пользователь с таким номером уже существует'}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/login', methods=['POST'])
def api_login():
    """API endpoint для авторизации"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        password = data.get('password', '').strip()
        
        # Валидация
        if not phone or not password:
            return jsonify({'success': False, 'message': 'Номер телефона и пароль обязательны'}), 400
        
        # Аутентификация
        user = authenticate_user(phone, password)
        
        if user:
            session['user_id'] = user['id']
            session['phone'] = user['phone']
            return jsonify({'success': True, 'message': 'Вход выполнен успешно', 'redirect': '/dashboard'})
        else:
            return jsonify({'success': False, 'message': 'Неверный номер телефона или пароль'}), 401
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """API endpoint для выхода"""
    session.clear()
    return jsonify({'success': True, 'redirect': '/login'})

@app.route('/dashboard')
def dashboard():
    """Страница после успешной авторизации"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', phone=session.get('phone'), user_id=session.get('user_id'))

@app.route('/api/chats', methods=['GET'])
def api_get_chats():
    """API endpoint для получения списка чатов (пользователей с перепиской)"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        chats = get_user_chats(session['user_id'])
        return jsonify({'success': True, 'chats': chats})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/users/search', methods=['GET'])
def api_search_users():
    """API endpoint для поиска пользователей по номеру телефона"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        search_query = request.args.get('q', '').strip()
        
        if not search_query:
            return jsonify({'success': True, 'users': []})
        
        # Убираем все нецифровые символы для поиска
        search_query = ''.join(filter(str.isdigit, search_query))
        
        if len(search_query) < 3:
            return jsonify({'success': True, 'users': []})
        
        users = search_users_by_phone(session['user_id'], search_query)
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages', methods=['GET'])
def api_get_messages():
    """API endpoint для получения сообщений с другим пользователем"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        other_user_id = request.args.get('user_id', type=int)
        if not other_user_id:
            return jsonify({'success': False, 'message': 'ID пользователя не указан'}), 400
        
        messages = get_messages(session['user_id'], other_user_id)
        return jsonify({'success': True, 'messages': messages})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/messages', methods=['POST'])
def api_send_message():
    """API endpoint для отправки сообщения"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        data = request.get_json()
        receiver_id = data.get('receiver_id')
        message = data.get('message', '').strip()
        
        if not receiver_id:
            return jsonify({'success': False, 'message': 'ID получателя не указан'}), 400
        
        if not message:
            return jsonify({'success': False, 'message': 'Сообщение не может быть пустым'}), 400
        
        message_id = send_message(session['user_id'], receiver_id, message)
        return jsonify({'success': True, 'message_id': message_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

@app.route('/api/user/<int:user_id>', methods=['GET'])
def api_get_user(user_id):
    """API endpoint для получения информации о пользователе"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Не авторизован'}), 401
    
    try:
        user = get_user_by_id(user_id)
        if user:
            return jsonify({'success': True, 'user': user})
        else:
            return jsonify({'success': False, 'message': 'Пользователь не найден'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': f'Ошибка сервера: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
